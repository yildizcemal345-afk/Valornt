package top.niunaijun.blackboxa.esp;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.os.Build;
import android.os.IBinder;
import android.view.ViewConfiguration;
import android.view.WindowManager;
import androidx.recyclerview.widget.ItemTouchHelper;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import top.niunaijun.blackboxa.patch.GamePidHelper;
import top.niunaijun.blackboxa.util.AppLog;

/* JADX INFO: loaded from: classes11.dex */
public final class EspOverlayService extends Service {
    private static final String ASSET_SOCK = "codev_sock";
    private static final long DAEMON_JOIN_MS = 800;
    private static final boolean ENABLE_CODEV_SOCK_ESP = true;
    private static final Object ESP_LOCK = new Object();
    private static final boolean INJECT_SOCK_CLIENT = true;
    private static final long SERVER_JOIN_MS = 3000;
    private static final String SOCK_FILE = "codev_sock";
    private static final long SOCK_RELAUNCH_MS = 4000;
    private static final String TAG = "BYSTOM_ESP";
    static Context ctx;
    private static EspOverlayService instance;
    private static long lastStartMs;
    private static Thread sockDaemonThread;
    static Process sockProcess;
    private static Thread socketServerThread;
    private EspCanvasView overlayView;
    private WindowManager windowManager;

    public static native void DrawOn(EspCanvasView espCanvasView, Canvas canvas, int i, int i2);

    private native void closeNative();

    public static native void closeSocket();

    public static native boolean getReady(int i);

    public static native boolean isServerListening();

    public static native boolean isSocketConnected();

    public static native boolean nativeFetchEspFrame(int i, int i2);

    public static native int nativeGetEspPlayerCount();

    public static native void nativeSetEspAimConfig(boolean z, int i, float f, float f2, float f3, float f4, float f5, int i2);

    public static native boolean tryAcceptClient(int i);

    static {
        System.loadLibrary("boxesp");
    }

    public static void start(Context context) {
        if (context != null) {
            context.getApplicationContext().startService(new Intent(context, (Class<?>) EspOverlayService.class));
        }
    }

    public static void stop(Context context) {
        if (context != null) {
            context.getApplicationContext().stopService(new Intent(context, (Class<?>) EspOverlayService.class));
        }
    }

    public static boolean isRunning() {
        return instance != null;
    }

    public static int getEspPlayerCount() {
        try {
            return nativeGetEspPlayerCount();
        } catch (Throwable th) {
            return 0;
        }
    }

    public static void onGameLaunched(Context context) {
        if (context == null) {
            return;
        }
        Context app = context.getApplicationContext();
        GamePidHelper.refreshPidFile(app);
        restartSockForGame(app);
    }

    public static void restartSockForGame(Context context) {
        if (context == null) {
            return;
        }
        Context app = context.getApplicationContext();
        synchronized (ESP_LOCK) {
            GamePidHelper.refreshPidFile(app);
            if (isSocketConnected()) {
                AppLog.i(TAG, "codev_sock already connected — game.pid refreshed");
                return;
            }
            stopSockProcessLocked();
            if (isServerListening()) {
                File bin = ensureSockBinary(app);
                AppLog.i(TAG, "restart codev_sock after game.pid update");
                launchSock(bin.getAbsolutePath(), app);
            }
        }
    }

    @Override // android.app.Service
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override // android.app.Service
    public void onCreate() {
        super.onCreate();
        ctx = this;
        instance = this;
        ensureSockBinary(this);
        GamePidHelper.refreshPidFile(this);
        GamePidHelper.startRefreshLoop(this);
        startPipeline(this, 0);
        EspAimSettings.applyToNative();
        this.windowManager = (WindowManager) getSystemService("window");
        this.overlayView = new EspCanvasView(this);
        drawCanvas();
    }

    @Override // android.app.Service
    public void onDestroy() {
        GamePidHelper.stopRefreshLoop();
        synchronized (ESP_LOCK) {
            closeNative();
            stopWorkersLocked();
        }
        if (this.overlayView != null) {
            try {
                this.windowManager.removeView(this.overlayView);
            } catch (Exception e) {
                AppLog.w(TAG, "removeView failed", e);
            }
            this.overlayView = null;
        }
        instance = null;
        super.onDestroy();
    }

    public static void startPipeline(final Context context, final int gameType) {
        synchronized (ESP_LOCK) {
            long now = System.currentTimeMillis();
            if (now - lastStartMs >= 5000 || !isServerListening()) {
                lastStartMs = now;
                stopWorkersLocked();
                socketServerThread = new Thread(new Runnable() { // from class: top.niunaijun.blackboxa.esp.EspOverlayService$$ExternalSyntheticLambda1
                    @Override // java.lang.Runnable
                    public final void run() {
                        EspOverlayService.lambda$startPipeline$0(gameType);
                    }
                }, "esp-socket-server");
                socketServerThread.start();
                sockDaemonThread = new Thread(new Runnable() { // from class: top.niunaijun.blackboxa.esp.EspOverlayService$$ExternalSyntheticLambda2
                    @Override // java.lang.Runnable
                    public final void run() {
                        EspOverlayService.runSockWatcher(context);
                    }
                }, "codev-sock-watch");
                sockDaemonThread.start();
            }
        }
    }

    static /* synthetic */ void lambda$startPipeline$0(int gameType) {
        AppLog.i(TAG, "socket server: bind/listen...");
        boolean ready = getReady(gameType);
        AppLog.i(TAG, "socket server ready=" + ready);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void runSockWatcher(Context context) {
        while (!Thread.currentThread().isInterrupted()) {
            for (int i = 0; i < 80; i++) {
                try {
                    if (isServerListening()) {
                        break;
                    }
                    Thread.sleep(100L);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    return;
                }
            }
            if (!isServerListening()) {
                Thread.sleep(500L);
            } else {
                if (!isSocketConnected()) {
                    tryAcceptClient(ItemTouchHelper.Callback.DEFAULT_DRAG_ANIMATION_DURATION);
                }
                Thread.sleep(500L);
            }
        }
    }

    private static void launchSock(String sockPath, Context launchCtx) {
        if (sockPath == null || sockPath.isEmpty()) {
            return;
        }
        File bin = new File(sockPath);
        if (!bin.canExecute()) {
            bin.setExecutable(true, false);
        }
        try {
            if (sockProcess != null) {
                sockProcess.destroy();
            }
            ProcessBuilder pb = new ProcessBuilder(sockPath);
            GamePidHelper.applySockPidEnv(pb.environment(), launchCtx);
            sockProcess = pb.directory(bin.getParentFile()).redirectErrorStream(true).start();
            new Thread(new Runnable() { // from class: top.niunaijun.blackboxa.esp.EspOverlayService$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() {
                    EspOverlayService.lambda$launchSock$2();
                }
            }, "codev-sock-log").start();
        } catch (IOException e) {
            AppLog.e(TAG, "failed to start codev_sock", e);
            sockProcess = null;
        }
    }

    static /* synthetic */ void lambda$launchSock$2() {
        try {
            BufferedReader r = new BufferedReader(new InputStreamReader(sockProcess.getInputStream()));
            while (true) {
                try {
                    String line = r.readLine();
                    if (line != null) {
                        AppLog.i(TAG, "codev_sock: " + line);
                    } else {
                        r.close();
                        return;
                    }
                } finally {
                }
            }
        } catch (IOException e) {
        }
    }

    private static void stopSockProcessLocked() {
        if (sockProcess != null) {
            try {
                sockProcess.destroy();
                sockProcess.waitFor();
            } catch (Throwable th) {
            }
            sockProcess = null;
        }
        try {
            Thread.sleep(250L);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    private static void stopWorkersLocked() {
        closeSocket();
        stopSockProcessLocked();
        interruptAndJoin(socketServerThread, SERVER_JOIN_MS);
        socketServerThread = null;
        interruptAndJoin(sockDaemonThread, DAEMON_JOIN_MS);
        sockDaemonThread = null;
    }

    private static void interruptAndJoin(Thread thread, long timeoutMs) {
        if (thread == null || !thread.isAlive()) {
            return;
        }
        thread.interrupt();
        try {
            thread.join(timeoutMs);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    static File ensureSockBinary(Context context) {
        return CodevSockHelper.ensureInstalled(context);
    }

    private void drawCanvas() {
        int layoutFlag;
        if (Build.VERSION.SDK_INT >= 26) {
            layoutFlag = 2038;
        } else {
            layoutFlag = 2006;
        }
        WindowManager.LayoutParams params = new WindowManager.LayoutParams(-1, -1, 0, getNavigationBarHeight(), layoutFlag, 536, 1);
        if (Build.VERSION.SDK_INT >= 28) {
            params.layoutInDisplayCutoutMode = 1;
        }
        params.gravity = 8388659;
        params.x = 0;
        params.y = 0;
        try {
            this.windowManager.addView(this.overlayView, params);
            AppLog.i(TAG, "esp overlay canvas added");
        } catch (Exception e) {
            AppLog.e(TAG, "addView failed — grant overlay permission", e);
            stopSelf();
        }
    }

    private int getNavigationBarHeight() {
        boolean hasMenuKey = ViewConfiguration.get(this).hasPermanentMenuKey();
        int resourceId = getResources().getIdentifier("navigation_bar_height", "dimen", "android");
        if (resourceId > 0 && !hasMenuKey) {
            return getResources().getDimensionPixelSize(resourceId);
        }
        return 0;
    }
}
