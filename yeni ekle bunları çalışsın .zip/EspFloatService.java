package top.niunaijun.blackboxa.esp;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import top.niunaijun.blackboxa.R;
import top.niunaijun.blackboxa.patch.GamePidHelper;
import top.niunaijun.blackboxa.util.AppLog;

/* JADX INFO: loaded from: classes11.dex */
public final class EspFloatService extends Service {
    public static final String ACTION_ENABLE_ESP = "ENABLE_ESP";
    private static final String TAG = "BYSTOM_ESP";
    private static EspFloatService sInstance;
    private SeekBar aimFovSeek;
    private TextView aimFovValue;
    private SeekBar aimSmoothSeek;
    private TextView aimSmoothValue;
    private SeekBar aimSpeedSeek;
    private TextView aimSpeedValue;
    private RadioGroup aimTriggerGroup;
    private Switch drawAim;
    private Switch drawEsp;
    private RelativeLayout layoutIconControlView;
    private LinearLayout layoutMainView;
    private View mainView;
    private WindowManager.LayoutParams paramsMainView;
    private WindowManager windowManager;
    private int aimFov = 120;
    private int aimSmooth = 8;
    private int aimSpeed = 20;
    private int aimTrigger = 1;
    private float aimTouchX = 900.0f;
    private float aimTouchY = 540.0f;

    private interface SeekProgress {
        void on(int i);
    }

    public static boolean isRunning() {
        return sInstance != null;
    }

    public static void start(Context context) {
        if (context == null) {
            return;
        }
        context.getApplicationContext().startService(new Intent(context, (Class<?>) EspFloatService.class));
    }

    public static void stop(Context context) {
        if (context != null) {
            Context app = context.getApplicationContext();
            app.stopService(new Intent(app, (Class<?>) EspFloatService.class));
            EspOverlayService.stop(app);
        }
    }

    public static void enableESP(Context context) {
        if (context == null) {
            return;
        }
        Context app = context.getApplicationContext();
        if (!Settings.canDrawOverlays(app)) {
            Toast.makeText(app, R.string.esp_overlay_permission_required, 1).show();
            return;
        }
        start(app);
        Intent intent = new Intent(app, (Class<?>) EspFloatService.class);
        intent.setAction(ACTION_ENABLE_ESP);
        app.startService(intent);
    }

    @Override // android.app.Service
    public void onCreate() {
        super.onCreate();
        sInstance = this;
        if (!canDrawOverlays()) {
            Toast.makeText(this, R.string.esp_overlay_permission_required, 1).show();
            stopSelf();
        } else {
            initMainView();
            startForegroundIfNeeded();
            AppLog.i(TAG, "FloatService menu shown");
        }
    }

    private void startForegroundIfNeeded() {
        if (Build.VERSION.SDK_INT < 26) {
            return;
        }
        NotificationManager nm = (NotificationManager) getSystemService(NotificationManager.class);
        if (nm != null) {
            NotificationChannel ch = new NotificationChannel("valorant_esp_float", getString(R.string.app_name), 2);
            nm.createNotificationChannel(ch);
        }
        Notification notification = new Notification.Builder(this, "valorant_esp_float").setContentTitle(getString(R.string.app_name)).setContentText(getString(R.string.esp_notification_text)).setSmallIcon(R.drawable.anubis_logo).build();
        startForeground(41, notification);
    }

    @Override // android.app.Service
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_ENABLE_ESP.equals(intent.getAction())) {
            if (this.drawEsp != null) {
                this.drawEsp.setChecked(true);
            } else if (canDrawOverlays()) {
                drawEsp();
            }
        }
        return 1;
    }

    @Override // android.app.Service
    public void onDestroy() {
        if (this.mainView != null && this.windowManager != null) {
            try {
                this.windowManager.removeView(this.mainView);
            } catch (Exception e) {
            }
        }
        sInstance = null;
        super.onDestroy();
    }

    @Override // android.app.Service
    public IBinder onBind(Intent intent) {
        return null;
    }

    private void initMainView() {
        this.mainView = LayoutInflater.from(this).inflate(R.layout.float_service_codev, (ViewGroup) null);
        this.paramsMainView = buildParams();
        this.windowManager = (WindowManager) getSystemService("window");
        this.layoutIconControlView = (RelativeLayout) this.mainView.findViewById(R.id.layout_icon_control_view);
        this.layoutMainView = (LinearLayout) this.mainView.findViewById(R.id.layout_main_view);
        View.OnClickListener minimizeListener = new View.OnClickListener() { // from class: top.niunaijun.blackboxa.esp.EspFloatService$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.lambda$initMainView$0(view);
            }
        };
        TextView minimizeBtn = (TextView) this.mainView.findViewById(R.id.minimize_btn);
        TextView closeBtn = (TextView) this.mainView.findViewById(R.id.close_btn);
        if (minimizeBtn != null) {
            minimizeBtn.setOnClickListener(minimizeListener);
        }
        if (closeBtn != null) {
            closeBtn.setOnClickListener(minimizeListener);
        }
        View iconBtn = this.mainView.findViewById(R.id.imageview_control);
        if (iconBtn != null) {
            iconBtn.setOnTouchListener(createDragListener(true));
        }
        View dragHandle = this.mainView.findViewById(R.id.menu_drag_handle);
        if (dragHandle != null) {
            dragHandle.setOnTouchListener(createDragListener(false));
        }
        showMenuIcon();
        this.drawEsp = (Switch) this.mainView.findViewById(R.id.isenableesp);
        if (this.drawEsp != null) {
            this.drawEsp.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() { // from class: top.niunaijun.blackboxa.esp.EspFloatService$$ExternalSyntheticLambda1
                @Override // android.widget.CompoundButton.OnCheckedChangeListener
                public final void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                    this.f$0.lambda$initMainView$1(compoundButton, z);
                }
            });
        }
        this.drawAim = (Switch) this.mainView.findViewById(R.id.isenableaim);
        View aimSection = this.mainView.findViewById(R.id.aim_section);
        if (aimSection != null) {
            aimSection.setVisibility(8);
        }
        this.aimFovSeek = (SeekBar) this.mainView.findViewById(R.id.aim_fov_seek);
        this.aimSmoothSeek = (SeekBar) this.mainView.findViewById(R.id.aim_smooth_seek);
        this.aimSpeedSeek = (SeekBar) this.mainView.findViewById(R.id.aim_speed_seek);
        this.aimFovValue = (TextView) this.mainView.findViewById(R.id.aim_fov_value);
        this.aimSmoothValue = (TextView) this.mainView.findViewById(R.id.aim_smooth_value);
        this.aimSpeedValue = (TextView) this.mainView.findViewById(R.id.aim_speed_value);
        this.aimTriggerGroup = (RadioGroup) this.mainView.findViewById(R.id.aim_trigger_group);
        updateAimLabels();
        pushAimConfig();
        try {
            this.windowManager.addView(this.mainView, this.paramsMainView);
        } catch (Exception e) {
            AppLog.e(TAG, "FloatService addView failed", e);
            Toast.makeText(this, R.string.esp_overlay_permission_required, 1).show();
            stopSelf();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$initMainView$0(View v) {
        showMenuIcon();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$initMainView$1(CompoundButton button, boolean checked) {
        if (checked) {
            drawEsp();
        } else {
            stopEsp();
        }
    }

    private /* synthetic */ void lambda$initMainView$2(int progress) {
        this.aimFov = Math.max(40, progress);
        updateAimLabels();
        pushAimConfig();
    }

    private /* synthetic */ void lambda$initMainView$3(int progress) {
        this.aimSmooth = Math.max(1, progress);
        updateAimLabels();
        pushAimConfig();
    }

    private /* synthetic */ void lambda$initMainView$4(int progress) {
        this.aimSpeed = Math.max(5, progress);
        updateAimLabels();
        pushAimConfig();
    }

    private /* synthetic */ void lambda$initMainView$5(RadioGroup group, int checkedId) {
        this.aimTrigger = checkedId == R.id.aim_trigger_always ? 0 : 1;
        pushAimConfig();
    }

    private /* synthetic */ void lambda$initMainView$6(CompoundButton button, boolean checked) {
        if (checked && (this.drawEsp == null || !this.drawEsp.isChecked())) {
            Toast.makeText(this, R.string.esp_aim_need_esp, 0).show();
        }
        pushAimConfig();
    }

    private void showMenuIcon() {
        if (this.layoutMainView != null) {
            this.layoutMainView.setVisibility(8);
        }
        if (this.layoutIconControlView != null) {
            this.layoutIconControlView.setVisibility(0);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void expandMenu() {
        if (this.layoutIconControlView != null) {
            this.layoutIconControlView.setVisibility(8);
        }
        if (this.layoutMainView != null) {
            this.layoutMainView.setVisibility(0);
        }
    }

    private View.OnTouchListener createDragListener(final boolean expandOnTap) {
        return new View.OnTouchListener() { // from class: top.niunaijun.blackboxa.esp.EspFloatService.1
            private float initialTouchX;
            private float initialTouchY;
            private int initialX;
            private int initialY;
            private boolean moved;

            @Override // android.view.View.OnTouchListener
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case 0:
                        this.initialX = EspFloatService.this.paramsMainView.x;
                        this.initialY = EspFloatService.this.paramsMainView.y;
                        this.initialTouchX = event.getRawX();
                        this.initialTouchY = event.getRawY();
                        this.moved = false;
                        return true;
                    case 1:
                        int xDiff = (int) (event.getRawX() - this.initialTouchX);
                        int yDiff = (int) (event.getRawY() - this.initialTouchY);
                        if (!this.moved && expandOnTap && Math.abs(xDiff) < 10 && Math.abs(yDiff) < 10 && EspFloatService.this.isViewCollapsed()) {
                            EspFloatService.this.expandMenu();
                        }
                        return true;
                    case 2:
                        int dx = (int) (event.getRawX() - this.initialTouchX);
                        int dy = (int) (event.getRawY() - this.initialTouchY);
                        if (Math.abs(dx) > 6 || Math.abs(dy) > 6) {
                            this.moved = true;
                        }
                        EspFloatService.this.paramsMainView.x = this.initialX + dx;
                        EspFloatService.this.paramsMainView.y = this.initialY + dy;
                        EspFloatService.this.windowManager.updateViewLayout(EspFloatService.this.mainView, EspFloatService.this.paramsMainView);
                        return true;
                    default:
                        return false;
                }
            }
        };
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean isViewCollapsed() {
        return this.layoutIconControlView != null && this.layoutIconControlView.getVisibility() == 0;
    }

    private void updateAimLabels() {
        if (this.aimFovValue != null) {
            this.aimFovValue.setText(getString(R.string.esp_aim_fov_value_fmt, new Object[]{Integer.valueOf(this.aimFov)}));
        }
        if (this.aimSmoothValue != null) {
            this.aimSmoothValue.setText(getString(R.string.esp_aim_smooth_value_fmt, new Object[]{Integer.valueOf(this.aimSmooth)}));
        }
        if (this.aimSpeedValue != null) {
            this.aimSpeedValue.setText(getString(R.string.esp_aim_speed_value_fmt, new Object[]{Integer.valueOf(this.aimSpeed)}));
        }
    }

    private static SeekBar.OnSeekBarChangeListener simpleSeek(final SeekProgress cb) {
        return new SeekBar.OnSeekBarChangeListener() { // from class: top.niunaijun.blackboxa.esp.EspFloatService.2
            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                cb.on(progress);
            }

            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        };
    }

    private void pushAimConfig() {
        EspAimSettings.enabled = false;
        EspAimSettings.applyToNative();
    }

    private void drawEsp() {
        if (!EspSocketEsp.isHostEspEnabled()) {
            Toast.makeText(this, "Host ESP disabled for inject-only testing", 0).show();
            if (this.drawEsp != null) {
                this.drawEsp.setChecked(false);
            }
            AppLog.i(TAG, "drawEsp ignored: host ESP disabled");
            return;
        }
        if (!canDrawOverlays()) {
            Toast.makeText(this, R.string.esp_overlay_permission_required, 0).show();
            if (this.drawEsp != null) {
                this.drawEsp.setChecked(false);
                return;
            }
            return;
        }
        GamePidHelper.writePidFileOnce(this);
        File sock = CodevSockHelper.ensureInstalled(this);
        pushAimConfig();
        startService(new Intent(this, (Class<?>) EspOverlayService.class));
        AppLog.i(TAG, "Overlay service started sock=" + sock.length() + "b");
    }

    private void stopEsp() {
        stopService(new Intent(this, (Class<?>) EspOverlayService.class));
    }

    private WindowManager.LayoutParams buildParams() {
        WindowManager.LayoutParams params = new WindowManager.LayoutParams(-2, -2, overlayLayoutType(), 8, -3);
        params.gravity = 51;
        params.x = 0;
        params.y = 100;
        return params;
    }

    private static int overlayLayoutType() {
        if (Build.VERSION.SDK_INT >= 26) {
            return 2038;
        }
        if (Build.VERSION.SDK_INT >= 24) {
            return 2002;
        }
        if (Build.VERSION.SDK_INT >= 23) {
            return 2005;
        }
        return 2003;
    }

    private boolean canDrawOverlays() {
        if (Build.VERSION.SDK_INT < 23) {
            return true;
        }
        return Settings.canDrawOverlays(this);
    }
}
