package top.niunaijun.blackboxa.esp;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.widget.Toast;
import top.niunaijun.blackboxa.R;
import top.niunaijun.blackboxa.util.AppLog;

/* JADX INFO: loaded from: classes11.dex */
public final class EspSocketEsp {
    private static final boolean ENABLE_CODEV_SOCK_ESP = true;
    private static final long ENABLE_ESP_DELAY_MS = 3000;
    private static final long GAME_LAUNCHED_DELAY_MS = 5000;
    private static final String HOST_PACKAGE = "top.niunaijun.blackbox";
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static final String TAG = "BYSTOM_ESP";

    private EspSocketEsp() {
    }

    public static boolean isCodev(String packageName) {
        return "com.tencent.tmgp.codev".equals(packageName) || (packageName != null && packageName.contains("codev"));
    }

    public static void startOnGameLaunch(Context context) {
        if (context == null) {
            return;
        }
        Context app = context.getApplicationContext();
        if (!"top.niunaijun.blackbox".equals(app.getPackageName())) {
            AppLog.w(TAG, "startOnGameLaunch skipped: not host pkg=" + app.getPackageName());
            return;
        }
        if (!canDrawOverlays(app)) {
            AppLog.w(TAG, "ESP overlay: grant 'Display over other apps' permission first");
            Toast.makeText(app, R.string.esp_overlay_permission_required, 1).show();
            try {
                Intent i = new Intent("android.settings.action.MANAGE_OVERLAY_PERMISSION", Uri.parse("package:" + app.getPackageName()));
                i.addFlags(268435456);
                app.startActivity(i);
                return;
            } catch (Exception e) {
                AppLog.w(TAG, "overlay settings intent failed", e);
                return;
            }
        }
        startFloater(app);
        EspOverlayService.start(app);
        AppLog.i(TAG, "Float menu + host ESP overlay started");
    }

    public static void stop(Context context) {
        if (context != null) {
            EspFloatService.stop(context.getApplicationContext());
        }
    }

    public static boolean isHostEspEnabled() {
        return true;
    }

    private static void startFloater(Context app) {
        if (!EspFloatService.isRunning()) {
            EspFloatService.start(app);
            AppLog.i(TAG, "FloatService started");
        }
    }

    private static boolean canDrawOverlays(Context context) {
        if (Build.VERSION.SDK_INT < 23) {
            return true;
        }
        return Settings.canDrawOverlays(context);
    }
}
