package top.niunaijun.blackboxa.patch;

import android.util.Log;
import androidx.core.internal.view.SupportMenu;
import com.google.android.material.card.MaterialCardViewHelper;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import kotlin.UByte;
import top.niunaijun.blackbox.core.system.user.BUserHandle;

/* JADX INFO: loaded from: classes11.dex */
final class Ue4HostScanner {
    private static final int CHUNK_SIZE = 65536;
    private static final int FUOBJECT_ITEM_SIZE = 24;
    private static final int MAX_ACTORS_PER_LEVEL = 2048;
    private static final int MAX_CLASS_SCAN = 120000;
    private static final int MAX_ESP_DIST_M = 250;
    private static final int MAX_HEURISTIC_SCAN = 30000;
    private static final int MAX_LEVEL_CLUSTER_SCAN = 25000;
    static final int MAX_SANE_CONTROLLERS = 12;
    static final int MAX_SANE_PLAYERS = 24;
    private static final int MIN_ENGINE_WORLD_ACTORS = 200;
    private static final int OFF_ACTOR_REPL_LOC = 168;
    private static final int OFF_ACTOR_ROOT = 408;
    private static final int OFF_CAMERA_POV_LOC = 848;
    private static final int OFF_CHAR_CAMP = 5800;
    private static final int OFF_CLASS = 16;
    private static final int OFF_CLUSTER_ACTORS = 40;
    private static final int OFF_CTRL_CAMERA = 864;
    private static final int OFF_CTRL_CHARACTER = 776;
    private static final int OFF_CTRL_PAWN = 840;
    private static final int OFF_CTRL_PAWN_ALT = 760;
    private static final int OFF_CTRL_PLAYER = 832;
    private static final int OFF_CTRL_PLAYER_STATE = 720;
    private static final int OFF_ENGINE_GAME_VIEWPORT = 2008;
    private static final int OFF_LEVEL_ACTOR_CLUSTER = 216;
    private static final int OFF_LEVEL_OWNING_WORLD = 184;
    private static final int OFF_NAME = 24;
    private static final int OFF_PAWN_CONTROLLER = 768;
    private static final int OFF_PLAYER_STATE_CAMP = 1196;
    private static final int OFF_ROOT_LOC = 308;
    private static final int OFF_STREAMING_LOADED_LEVEL = 296;
    private static final int OFF_SUPER_STRUCT = 48;
    private static final int OFF_VIEWPORT_WORLD = 112;
    private static final int OFF_WORLD_LEVELS = 432;
    private static final int OFF_WORLD_PERSISTENT_LEVEL = 48;
    private static final int OFF_WORLD_STREAMING_LEVELS = 216;
    private static final long PTR_MAX = 281474976710655L;
    private static final long PTR_MIN = 4294967296L;
    private static final String TAG = "BYSTOM_ESP";
    private static int sBadWorldStreak;
    private static long sCachedGnamesPool;
    private static long sCachedLocalController;
    private static long sCachedRichLevel;
    private static long sCachedWorld;
    private static boolean sClassLookupDone;
    private static long sControllerClassByName;
    private static int sEmptyActorStreak;
    private static boolean sFnameCtrlClass;
    private static boolean sFnamePlayerClass;
    private static boolean sGnamesAlive;
    private static long sGnamesGlobalSlot;
    private static boolean sGuCtrlScanned;
    private static long sPlayerClassByName;
    private static int sEngineIndex = -1;
    private static int sViewportIndex = -1;
    private static int sCachedPid = -1;
    private static int sCachedCtrlIndex = -1;

    /* JADX INFO: Access modifiers changed from: private */
    interface ActorPredicate {
        boolean test(ProcMemSession procMemSession, long j);
    }

    private Ue4HostScanner() {
    }

    static final class ScanResult {
        int actors;
        float camX;
        float camY;
        float camZ;
        boolean classBootstrapped;
        boolean controllerClassFound;
        int controllers;
        int diagHumanoid;
        int diagLooseCtrl;
        int diagMapPawn;
        int enemies;
        int localCamp = -1;
        float localX;
        float localY;
        float localZ;
        boolean playerClassFound;
        int players;
        int scanBestActors;
        long scanBestWorld;
        long world;
        boolean worldFound;

        ScanResult() {
        }
    }

    static void resetCache(int pid) {
        if (pid != sCachedPid) {
            sCachedPid = pid;
            sPlayerClassByName = 0L;
            sControllerClassByName = 0L;
            sCachedGnamesPool = 0L;
            sCachedWorld = 0L;
            sEngineIndex = -1;
            sViewportIndex = -1;
            sEmptyActorStreak = 0;
            sBadWorldStreak = 0;
            sClassLookupDone = false;
            sFnamePlayerClass = false;
            sFnameCtrlClass = false;
            sGnamesAlive = false;
            sGuCtrlScanned = false;
            sCachedCtrlIndex = -1;
            sCachedLocalController = 0L;
            sCachedRichLevel = 0L;
            sGnamesGlobalSlot = 0L;
        }
    }

    static ScanResult scan(ProcMemSession mem, long guObjAddr, int numElements, long gnamesPool, long gnamesGlobalSlot) {
        ProcMemSession procMemSession = mem;
        ScanResult r = new ScanResult();
        if (procMemSession == null || !isPlausiblePtr(guObjAddr) || numElements <= 0) {
            return r;
        }
        resetCache(procMemSession.pid());
        sGnamesGlobalSlot = gnamesGlobalSlot;
        if (sEmptyActorStreak >= 3) {
            sCachedWorld = 0L;
            sCachedRichLevel = 0L;
        }
        WorldPick pick = new WorldPick();
        Log.i(TAG, "scan: findWorld...");
        long world = findWorld(procMemSession, guObjAddr, numElements, pick);
        Log.i(TAG, String.format("scan: world=0x%x actors~%d", Long.valueOf(world), Integer.valueOf(pick.actors)));
        r.scanBestActors = pick.actors;
        r.scanBestWorld = pick.world;
        if (!isPlausiblePtr(world)) {
            return r;
        }
        r.world = world;
        r.worldFound = true;
        List<Long> actorList = collectActors(procMemSession, guObjAddr, numElements, world);
        r.actors = actorList.size();
        if (r.actors >= 200 && r.actors > 0) {
            sCachedWorld = world;
        }
        if (actorList.isEmpty()) {
            sEmptyActorStreak++;
            if (isPlausiblePtr(world)) {
                sCachedWorld = 0L;
            }
            logWorldActorDiag(procMemSession, world);
            return r;
        }
        sEmptyActorStreak = 0;
        Log.i(TAG, "scan: classes...");
        long j = 0;
        ensureClasses(procMemSession, guObjAddr, numElements, gnamesPool, gnamesGlobalSlot, actorList);
        r.diagLooseCtrl = countInList(procMemSession, actorList, new ActorPredicate() { // from class: top.niunaijun.blackboxa.patch.Ue4HostScanner$$ExternalSyntheticLambda1
            @Override // top.niunaijun.blackboxa.patch.Ue4HostScanner.ActorPredicate
            public final boolean test(ProcMemSession procMemSession2, long j2) {
                return Ue4HostScanner.isLoosePlayerController(procMemSession2, j2);
            }
        });
        r.diagHumanoid = countInList(procMemSession, actorList, new ActorPredicate() { // from class: top.niunaijun.blackboxa.patch.Ue4HostScanner$$ExternalSyntheticLambda2
            @Override // top.niunaijun.blackboxa.patch.Ue4HostScanner.ActorPredicate
            public final boolean test(ProcMemSession procMemSession2, long j2) {
                return Ue4HostScanner.isHumanoidPlayer(procMemSession2, j2);
            }
        });
        r.diagMapPawn = countInList(procMemSession, actorList, new ActorPredicate() { // from class: top.niunaijun.blackboxa.patch.Ue4HostScanner$$ExternalSyntheticLambda3
            @Override // top.niunaijun.blackboxa.patch.Ue4HostScanner.ActorPredicate
            public final boolean test(ProcMemSession procMemSession2, long j2) {
                return Ue4HostScanner.isMapCharacter(procMemSession2, j2);
            }
        });
        Log.i(TAG, String.format("scan: actors=%d diag lc=%d hum=%d map=%d", Integer.valueOf(actorList.size()), Integer.valueOf(r.diagLooseCtrl), Integer.valueOf(r.diagHumanoid), Integer.valueOf(r.diagMapPawn)));
        if (r.diagMapPawn == 0 && r.actors >= 200) {
            sBadWorldStreak++;
            if (sBadWorldStreak >= 2) {
                Log.i(TAG, "scan: no map chars — clear world cache, rescan next");
                sCachedWorld = 0L;
                sBadWorldStreak = 0;
            }
        } else if (r.diagMapPawn > 0) {
            sBadWorldStreak = 0;
        }
        Log.i(TAG, "scan: findController...");
        long localCtrl = findLocalController(procMemSession, guObjAddr, numElements, actorList);
        if (localCtrl != 0) {
            r.controllers = 1;
            sCachedLocalController = localCtrl;
        }
        long localPlayer = localCtrl != 0 ? playerFromController(procMemSession, localCtrl) : 0L;
        if (localPlayer == 0 && sControllerClassByName != 0) {
            Iterator<Long> it = actorList.iterator();
            while (it.hasNext()) {
                WorldPick pick2 = pick;
                long actor = it.next().longValue();
                if (isSubclassOf(procMemSession, actor, sControllerClassByName)) {
                    localCtrl = actor;
                    r.controllers = 1;
                    sCachedLocalController = actor;
                    localPlayer = playerFromController(procMemSession, actor);
                    if (localPlayer != 0) {
                        break;
                    }
                    pick = pick2;
                } else {
                    pick = pick2;
                }
            }
        }
        if (localPlayer == 0) {
            Iterator<Long> it2 = actorList.iterator();
            while (it2.hasNext()) {
                long actor2 = it2.next().longValue();
                if (isMapCharacter(procMemSession, actor2) && (sPlayerClassByName == 0 || isSubclassOf(procMemSession, actor2, sPlayerClassByName))) {
                    localPlayer = actor2;
                    break;
                }
            }
        }
        r.players = countInList(procMemSession, actorList, new ActorPredicate() { // from class: top.niunaijun.blackboxa.patch.Ue4HostScanner$$ExternalSyntheticLambda4
            @Override // top.niunaijun.blackboxa.patch.Ue4HostScanner.ActorPredicate
            public final boolean test(ProcMemSession procMemSession2, long j2) {
                return Ue4HostScanner.isEspPlayer(procMemSession2, j2);
            }
        });
        if (localPlayer == 0) {
            r.playerClassFound = sFnamePlayerClass;
            r.controllerClassFound = sFnameCtrlClass;
            r.classBootstrapped = (sPlayerClassByName == 0 && sControllerClassByName == 0) ? false : true;
            if (localCtrl != 0) {
                float[] cam = readCameraPosition(procMemSession, localCtrl);
                r.camX = cam[0];
                r.camY = cam[1];
                r.camZ = cam[2];
            }
            return r;
        }
        r.localCamp = readCamp(procMemSession, localPlayer, localCtrl);
        if (r.localCamp < 1 || r.localCamp > 4) {
            r.localCamp = 1;
        }
        r.playerClassFound = sFnamePlayerClass;
        r.controllerClassFound = sFnameCtrlClass;
        r.classBootstrapped = (sPlayerClassByName == 0 && sControllerClassByName == 0) ? false : true;
        float[] pos = readLocalPosition(procMemSession, localPlayer, localCtrl);
        r.localX = pos[0];
        r.localY = pos[1];
        r.localZ = pos[2];
        float[] cam2 = readCameraPosition(procMemSession, localCtrl);
        r.camX = cam2[0];
        r.camY = cam2[1];
        r.camZ = cam2[2];
        Iterator<Long> it3 = actorList.iterator();
        while (it3.hasNext()) {
            long actor3 = it3.next().longValue();
            if (actor3 != localPlayer && isEspPlayer(procMemSession, actor3)) {
                float[] cam3 = cam2;
                int camp = readCamp(procMemSession, actor3, j);
                if (camp < 1 || camp > 4 || camp != r.localCamp) {
                    float[] feet = readLocation(procMemSession, actor3);
                    if (!hasMapPosition(feet)) {
                        cam2 = cam3;
                        j = 0;
                    } else if (distanceMeters(pos, feet) > 250.0f) {
                        cam2 = cam3;
                        j = 0;
                    } else {
                        r.enemies++;
                        if (r.enemies >= 32) {
                            break;
                        }
                        procMemSession = mem;
                        cam2 = cam3;
                        j = 0;
                    }
                } else {
                    cam2 = cam3;
                    j = 0;
                }
            }
        }
        return r;
    }

    private static void ensureClasses(ProcMemSession mem, long guObjAddr, int numElements, long gnamesPool, long gnamesGlobalSlot, List<Long> actors) {
        ProcMemSession procMemSession = mem;
        long pool = resolveGNamesPool(procMemSession, gnamesPool, gnamesGlobalSlot);
        sGnamesAlive = isGNamesAlive(procMemSession, pool);
        if (!sClassLookupDone) {
            sClassLookupDone = true;
            if (sGnamesAlive) {
                Log.i(TAG, "scan: findUClass (FName ok)...");
                if (sPlayerClassByName == 0) {
                    sPlayerClassByName = findUClass(procMemSession, guObjAddr, numElements, pool, "CVPlayerCharacter");
                    sFnamePlayerClass = sPlayerClassByName != 0;
                }
                if (sControllerClassByName != 0) {
                    procMemSession = mem;
                } else {
                    procMemSession = mem;
                    sControllerClassByName = findUClass(procMemSession, guObjAddr, numElements, pool, "CVPlayerController");
                    sFnameCtrlClass = sControllerClassByName != 0;
                }
            } else {
                Log.i(TAG, "scan: skip findUClass (FName empty, use bootstrap)");
            }
        }
        if (sControllerClassByName == 0) {
            long boot = bootstrapControllerClass(procMemSession, actors);
            if (boot != 0) {
                sControllerClassByName = boot;
            }
        }
        if (sPlayerClassByName == 0) {
            long boot2 = bootstrapPlayerClass(procMemSession, actors);
            if (boot2 != 0) {
                sPlayerClassByName = boot2;
            }
        }
    }

    private static int countInList(ProcMemSession mem, List<Long> actors, ActorPredicate pred) {
        int n = 0;
        Iterator<Long> it = actors.iterator();
        while (it.hasNext()) {
            long actor = it.next().longValue();
            if (pred.test(mem, actor)) {
                n++;
            }
        }
        return n;
    }

    private static long bootstrapControllerClass(ProcMemSession mem, List<Long> actors) {
        Iterator<Long> it = actors.iterator();
        while (it.hasNext()) {
            long actor = it.next().longValue();
            if (isLoosePlayerController(mem, actor)) {
                long cls = readPtr(mem, 16 + actor);
                if (isPlausiblePtr(cls)) {
                    return cls;
                }
            }
        }
        return 0L;
    }

    private static long bootstrapPlayerClass(ProcMemSession mem, List<Long> actors) {
        Iterator<Long> it = actors.iterator();
        while (it.hasNext()) {
            long actor = it.next().longValue();
            if (isLoosePlayerController(mem, actor)) {
                long pawn = readPtr(mem, 840 + actor);
                long cls = readPtr(mem, 16 + pawn);
                if (isPlausiblePtr(cls)) {
                    return cls;
                }
            }
        }
        Iterator<Long> it2 = actors.iterator();
        while (it2.hasNext()) {
            long actor2 = it2.next().longValue();
            if (isLocalPawn(mem, actor2) || isHumanoidPlayer(mem, actor2)) {
                long cls2 = readPtr(mem, actor2 + 16);
                if (isPlausiblePtr(cls2)) {
                    return cls2;
                }
            }
        }
        return 0L;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static boolean isEspPlayer(ProcMemSession mem, long actor) {
        if (!isMapCharacter(mem, actor)) {
            return false;
        }
        if (sPlayerClassByName != 0) {
            return isSubclassOf(mem, actor, sPlayerClassByName);
        }
        return isPlayerCharacter(mem, actor);
    }

    private static long findLocalController(ProcMemSession mem, long guObjAddr, int numElements, List<Long> actors) {
        int score;
        long obj;
        int score2;
        if (isPlausiblePtr(sCachedLocalController) && scoreControllerCandidate(mem, sCachedLocalController) >= 80) {
            return sCachedLocalController;
        }
        long best = 0;
        int bestScore = 0;
        Iterator<Long> it = actors.iterator();
        while (it.hasNext()) {
            long actor = it.next().longValue();
            if (sControllerClassByName == 0 || isSubclassOf(mem, actor, sControllerClassByName)) {
                int score3 = scoreControllerCandidate(mem, actor);
                if (score3 > bestScore) {
                    bestScore = score3;
                    best = actor;
                }
            }
        }
        if (bestScore >= 80) {
            sCachedCtrlIndex = -1;
            return best;
        }
        if (sCachedCtrlIndex >= 0 && sCachedCtrlIndex < numElements && (score2 = scoreControllerCandidate(mem, (obj = objectAt(mem, guObjAddr, numElements, sCachedCtrlIndex)))) > bestScore) {
            bestScore = score2;
            best = obj;
        }
        if (!sGuCtrlScanned) {
            sGuCtrlScanned = true;
            Log.i(TAG, "scan: GUObject controller search (once)...");
            int limit = Math.min(numElements, 8000);
            for (int i = 0; i < limit; i++) {
                long obj2 = objectAt(mem, guObjAddr, numElements, i);
                if ((sControllerClassByName == 0 || isSubclassOf(mem, obj2, sControllerClassByName)) && (score = scoreControllerCandidate(mem, obj2)) > bestScore) {
                    bestScore = score;
                    best = obj2;
                    sCachedCtrlIndex = i;
                }
            }
        }
        if (bestScore >= 20) {
            return best;
        }
        return 0L;
    }

    private static int scoreControllerCandidate(ProcMemSession mem, long ctrl) {
        if (!isPlausiblePtr(ctrl)) {
            return 0;
        }
        long pawn = readPtr(mem, 840 + ctrl);
        if (!isPlausiblePtr(pawn)) {
            pawn = readPtr(mem, 760 + ctrl);
        }
        long camera = readPtr(mem, 864 + ctrl);
        if (!isPlausiblePtr(pawn) || !isPlausiblePtr(camera)) {
            return 0;
        }
        int score = 20;
        if (readPtr(mem, 768 + pawn) == ctrl) {
            score = 20 + 50;
        }
        long player = readPtr(mem, 832 + ctrl);
        long playerState = readPtr(mem, 720 + ctrl);
        if (isPlausiblePtr(player) || isPlausiblePtr(playerState)) {
            score += 15;
        }
        float[] cam = readCameraPosition(mem, ctrl);
        if (hasMapPosition(cam)) {
            score += 120;
        } else if (hasNonTrivialPosition(cam)) {
            score += 30;
        }
        float[] pawnPos = readLocation(mem, pawn);
        if (hasMapPosition(pawnPos)) {
            score += 100;
        }
        long character = readPtr(mem, 776 + ctrl);
        if (isPlausiblePtr(character) && hasMapPosition(readLocation(mem, character))) {
            return score + 80;
        }
        return score;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static boolean isLoosePlayerController(ProcMemSession mem, long actor) {
        long pawn = readPtr(mem, 840 + actor);
        if (!isPlausiblePtr(pawn)) {
            pawn = readPtr(mem, 760 + actor);
        }
        long camera = readPtr(mem, 864 + actor);
        return isPlausiblePtr(pawn) && isPlausiblePtr(camera);
    }

    private static boolean isVerifiedPlayerController(ProcMemSession mem, long actor) {
        if (!isLoosePlayerController(mem, actor)) {
            return false;
        }
        long pawn = readPtr(mem, 840 + actor);
        return readPtr(mem, 768 + pawn) == actor;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static boolean isMapCharacter(ProcMemSession mem, long actor) {
        if (isPlausiblePtr(actor) && isPlausiblePtr(readPtr(mem, 408 + actor))) {
            return hasNonTrivialPosition(readLocation(mem, actor));
        }
        return false;
    }

    private static boolean hasMapPosition(float[] p) {
        if (isSanePosition(p)) {
            return Math.abs(p[0]) > 500.0f || Math.abs(p[1]) > 500.0f;
        }
        return false;
    }

    private static boolean hasNonTrivialPosition(float[] p) {
        if (isSanePosition(p)) {
            return Math.abs(p[0]) > 1.0f || Math.abs(p[1]) > 1.0f || Math.abs(p[2]) > 1.0f;
        }
        return false;
    }

    private static boolean isSanePosition(float[] p) {
        if (p == null || p.length < 3) {
            return false;
        }
        for (float v : p) {
            if (!Ue4HostScanner$$ExternalSyntheticBackport0.m(v) || Math.abs(v) > 2000000.0f) {
                return false;
            }
        }
        return true;
    }

    private static float[] readLocalPosition(ProcMemSession mem, long player, long controller) {
        float[] pos = readLocation(mem, player);
        if (!hasMapPosition(pos) && isPlausiblePtr(controller)) {
            float[] cam = readCameraPosition(mem, controller);
            if (hasMapPosition(cam)) {
                return cam;
            }
        }
        return pos;
    }

    private static float[] readCameraPosition(ProcMemSession mem, long controller) {
        byte[] buf;
        float[] out = new float[3];
        long camera = readPtr(mem, 864 + controller);
        if (isPlausiblePtr(camera) && (buf = mem.read(848 + camera, 12)) != null) {
            float x = ProcMemHelper.readF32(buf, 0);
            float y = ProcMemHelper.readF32(buf, 4);
            float z = ProcMemHelper.readF32(buf, 8);
            if (isSanePosition(new float[]{x, y, z})) {
                out[0] = x;
                out[1] = y;
                out[2] = z;
            }
        }
        return out;
    }

    private static boolean isLocalPawn(ProcMemSession mem, long actor) {
        if (!isPlausiblePtr(actor)) {
            return false;
        }
        float[] pos = readLocation(mem, actor);
        if (Math.abs(pos[0]) < 1000.0f && Math.abs(pos[1]) < 1000.0f && Math.abs(pos[2]) < 500.0f) {
            return false;
        }
        long root = readPtr(mem, 408 + actor);
        return isPlausiblePtr(root);
    }

    private static boolean isPlayerCharacter(ProcMemSession mem, long actor) {
        if (!isPlausiblePtr(actor)) {
            return false;
        }
        if (sPlayerClassByName != 0) {
            if (!isSubclassOf(mem, actor, sPlayerClassByName)) {
                return false;
            }
        } else if (!isHumanoidPlayer(mem, actor)) {
            return false;
        }
        int camp = mem.readI32(5800 + actor);
        if (camp < 1 || camp > 4) {
            return false;
        }
        float[] pos = readLocation(mem, actor);
        return Math.abs(pos[0]) >= 1.0f || Math.abs(pos[1]) >= 1.0f || Math.abs(pos[2]) >= 1.0f;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static boolean isHumanoidPlayer(ProcMemSession mem, long actor) {
        int camp;
        if (!isPlausiblePtr(actor) || (camp = mem.readI32(5800 + actor)) < 1 || camp > 4) {
            return false;
        }
        float[] pos = readLocation(mem, actor);
        return (Math.abs(pos[0]) >= 1.0f || Math.abs(pos[1]) >= 1.0f || Math.abs(pos[2]) >= 1.0f) && Math.abs(pos[0]) < 500000.0f && Math.abs(pos[1]) < 500000.0f;
    }

    private static int readCamp(ProcMemSession mem, long character, long controller) {
        int camp;
        int camp2 = mem.readI32(5800 + character);
        if (camp2 >= 1 && camp2 <= 4) {
            return camp2;
        }
        if (isPlausiblePtr(controller)) {
            long ps = readPtr(mem, 720 + controller);
            if (isPlausiblePtr(ps) && (camp = mem.readI32(1196 + ps)) >= 1 && camp <= 4) {
                return camp;
            }
            return -1;
        }
        return -1;
    }

    private static long playerFromController(ProcMemSession mem, long controller) {
        long pawn = readPtr(mem, 840 + controller);
        if (!isPlausiblePtr(pawn)) {
            pawn = readPtr(mem, 760 + controller);
        }
        if (isLocalPawn(mem, pawn) || isPlayerCharacter(mem, pawn) || isHumanoidPlayer(mem, pawn)) {
            return pawn;
        }
        long ch = readPtr(mem, 776 + controller);
        if (isLocalPawn(mem, ch) || isPlayerCharacter(mem, ch) || isHumanoidPlayer(mem, ch)) {
            return ch;
        }
        if (isPlausiblePtr(pawn)) {
            return pawn;
        }
        return 0L;
    }

    private static final class WorldPick {
        int actors;
        long world;

        private WorldPick() {
        }
    }

    private static void considerWorld(ProcMemSession mem, long world, WorldPick pick, Set<Long> seen) {
        if (!isPlausiblePtr(world) || seen.contains(Long.valueOf(world))) {
            return;
        }
        seen.add(Long.valueOf(world));
        int n = countActorsQuick(mem, world);
        if (n > pick.actors) {
            pick.actors = n;
            pick.world = world;
        } else if (pick.world == 0) {
            pick.world = world;
            pick.actors = n;
        }
    }

    private static long findEngineWorld(ProcMemSession mem, long guObjAddr, int numElements) {
        if (sEngineIndex >= 0 && sEngineIndex < numElements) {
            long w = worldFromEngine(mem, objectAt(mem, guObjAddr, numElements, sEngineIndex));
            if (isPlausiblePtr(w)) {
                return w;
            }
        }
        int limit = Math.min(numElements, MAX_HEURISTIC_SCAN);
        for (int i = 0; i < limit; i++) {
            long obj = objectAt(mem, guObjAddr, numElements, i);
            if (isPlausiblePtr(obj)) {
                long viewport = readPtr(mem, 2008 + obj);
                if (isPlausiblePtr(viewport)) {
                    sEngineIndex = i;
                    long w2 = worldFromViewport(mem, viewport);
                    if (isPlausiblePtr(w2)) {
                        return w2;
                    }
                } else {
                    continue;
                }
            }
        }
        return 0L;
    }

    private static void findWorldByLevelClusters(ProcMemSession mem, long guObjAddr, int numElements, WorldPick pick) {
        long j;
        ProcMemSession procMemSession = mem;
        long j2 = 184;
        if (isPlausiblePtr(sCachedRichLevel)) {
            long world = readPtr(procMemSession, sCachedRichLevel + 184);
            int n = countLevelActors(procMemSession, sCachedRichLevel);
            if (isPlausibleWorld(procMemSession, world) && n > pick.actors) {
                pick.world = world;
                pick.actors = n;
                if (n >= 200) {
                    return;
                }
            }
        }
        int limit = Math.min(numElements, MAX_LEVEL_CLUSTER_SCAN);
        long bestLevel = 0;
        int i = 0;
        while (i < limit) {
            long level = objectAt(procMemSession, guObjAddr, numElements, i);
            if (!isPlausiblePtr(level)) {
                j = j2;
            } else {
                long cluster = readPtr(procMemSession, 216 + level);
                if (!isPlausiblePtr(cluster)) {
                    j = j2;
                } else {
                    j = j2;
                    int n2 = countValidPtrInTArray(procMemSession, cluster + 40);
                    if (n2 > pick.actors) {
                        long world2 = readPtr(procMemSession, level + j);
                        if (isPlausibleWorld(procMemSession, world2)) {
                            pick.actors = n2;
                            pick.world = world2;
                            bestLevel = level;
                            if (n2 >= 200) {
                                break;
                            }
                        }
                    }
                    i++;
                    procMemSession = mem;
                    j2 = j;
                }
            }
            i++;
            procMemSession = mem;
            j2 = j;
        }
        if (isPlausiblePtr(bestLevel)) {
            sCachedRichLevel = bestLevel;
        }
    }

    private static long findWorld(ProcMemSession mem, long guObjAddr, int numElements, WorldPick pick) {
        findWorldByLevelClusters(mem, guObjAddr, numElements, pick);
        if (pick.actors < 200) {
            Set<Long> seen = new HashSet<>();
            long engineWorld = findEngineWorld(mem, guObjAddr, numElements);
            if (isPlausiblePtr(engineWorld)) {
                considerWorld(mem, engineWorld, pick, seen);
            }
            if (isPlausiblePtr(sCachedWorld) && !seen.contains(Long.valueOf(sCachedWorld))) {
                considerWorld(mem, sCachedWorld, pick, seen);
            }
        }
        if (pick.world == 0) {
            long engineWorld2 = findEngineWorld(mem, guObjAddr, numElements);
            if (isPlausiblePtr(engineWorld2)) {
                pick.world = engineWorld2;
            }
        }
        if (pick.actors >= 50 && isPlausiblePtr(pick.world)) {
            sCachedWorld = pick.world;
        }
        return pick.world;
    }

    private static long worldFromEngine(ProcMemSession mem, long engineObj) {
        if (!isPlausiblePtr(engineObj)) {
            return 0L;
        }
        long viewport = readPtr(mem, 2008 + engineObj);
        if (isPlausiblePtr(viewport)) {
            return worldFromViewport(mem, viewport);
        }
        return 0L;
    }

    private static long worldFromViewport(ProcMemSession mem, long viewport) {
        if (!isPlausiblePtr(viewport)) {
            return 0L;
        }
        long world = readPtr(mem, 112 + viewport);
        if (isValidWorld(mem, world)) {
            return world;
        }
        return 0L;
    }

    private static boolean isPlausibleWorld(ProcMemSession mem, long world) {
        if (!isPlausiblePtr(world)) {
            return false;
        }
        return isPlausiblePtr(readPtr(mem, 48 + world));
    }

    private static boolean isValidWorld(ProcMemSession mem, long world) {
        if (!isPlausiblePtr(world)) {
            return false;
        }
        long pl = readPtr(mem, 48 + world);
        return isPlausiblePtr(pl) && readPtr(mem, 184 + pl) == world;
    }

    private static int tarrayCount(ProcMemSession mem, long tarrayAddr) {
        long data = readPtr(mem, tarrayAddr);
        int count = mem.readI32(8 + tarrayAddr);
        if (!isPlausiblePtr(data) || count < 0 || count > 4096) {
            return -1;
        }
        return count;
    }

    private static int countActorsQuick(ProcMemSession mem, long world) {
        if (!isPlausiblePtr(world)) {
            return 0;
        }
        int total = countLevelActors(mem, readPtr(mem, 48 + world));
        int streamCount = tarrayCount(mem, world + 216);
        if (streamCount > 0) {
            long streamData = readPtr(mem, 216 + world);
            for (int i = 0; i < streamCount; i++) {
                long streaming = readPtr(mem, (((long) i) * 8) + streamData);
                if (isPlausiblePtr(streaming)) {
                    total += countLevelActors(mem, readPtr(mem, 296 + streaming));
                }
            }
        }
        int levelsCount = tarrayCount(mem, world + 432);
        if (levelsCount > 0) {
            long levelsData = readPtr(mem, 432 + world);
            for (int i2 = 0; i2 < levelsCount; i2++) {
                total += countLevelActors(mem, readPtr(mem, (((long) i2) * 8) + levelsData));
            }
        }
        return total;
    }

    private static int countLevelActors(ProcMemSession mem, long level) {
        if (!isPlausiblePtr(level)) {
            return 0;
        }
        long cluster = readPtr(mem, 216 + level);
        if (isPlausiblePtr(cluster)) {
            return countValidPtrInTArray(mem, 40 + cluster);
        }
        return 0;
    }

    private static int countValidPtrInTArray(ProcMemSession mem, long tarrayAddr) {
        long data = readPtr(mem, tarrayAddr);
        int count = mem.readI32(tarrayAddr + 8);
        if (!isPlausiblePtr(data) || count <= 0 || count > 8000) {
            return 0;
        }
        int valid = 0;
        int limit = Math.min(count, 2048);
        for (int i = 0; i < limit; i++) {
            if (isPlausiblePtr(readPtr(mem, (((long) i) * 8) + data))) {
                valid++;
            }
        }
        return valid;
    }

    private static List<Long> collectActors(ProcMemSession mem, long guObjAddr, int numElements, long world) {
        Set<Long> seen = new HashSet<>();
        List<Long> out = new ArrayList<>();
        collectActorsFromLevel(mem, readPtr(mem, world + 48), seen, out);
        int streamCount = tarrayCount(mem, world + 216);
        if (streamCount > 0) {
            long streamData = readPtr(mem, world + 216);
            for (int i = 0; i < streamCount; i++) {
                long streaming = readPtr(mem, (((long) i) * 8) + streamData);
                if (isPlausiblePtr(streaming)) {
                    collectActorsFromLevel(mem, readPtr(mem, 296 + streaming), seen, out);
                }
            }
        }
        int levelsCount = tarrayCount(mem, world + 432);
        if (levelsCount > 0) {
            long levelsData = readPtr(mem, world + 432);
            for (int i2 = 0; i2 < levelsCount; i2++) {
                collectActorsFromLevel(mem, readPtr(mem, (((long) i2) * 8) + levelsData), seen, out);
            }
        }
        if (out.isEmpty() && isPlausiblePtr(sCachedRichLevel)) {
            collectActorsFromLevel(mem, sCachedRichLevel, seen, out);
        }
        if (out.isEmpty() && isPlausiblePtr(guObjAddr) && numElements > 0) {
            collectActorsFromOwnedLevels(mem, guObjAddr, numElements, world, seen, out);
        }
        return out;
    }

    private static void collectActorsFromOwnedLevels(ProcMemSession mem, long guObjAddr, int numElements, long world, Set<Long> seen, List<Long> out) {
        int limit = Math.min(numElements, MAX_LEVEL_CLUSTER_SCAN);
        for (int i = 0; i < limit; i++) {
            long level = objectAt(mem, guObjAddr, numElements, i);
            if (isPlausiblePtr(level) && readPtr(mem, 184 + level) == world) {
                collectActorsFromLevel(mem, level, seen, out);
            }
        }
    }

    private static void collectActorsFromLevel(ProcMemSession mem, long level, Set<Long> seen, List<Long> out) {
        if (!isPlausiblePtr(level)) {
            return;
        }
        long cluster = readPtr(mem, 216 + level);
        if (isPlausiblePtr(cluster)) {
            appendActorsFromTArray(mem, 40 + cluster, seen, out);
        }
    }

    private static void logWorldActorDiag(ProcMemSession mem, long world) {
        long pl = readPtr(mem, world + 48);
        long owning = isPlausiblePtr(pl) ? readPtr(mem, 184 + pl) : 0L;
        long cluster = isPlausiblePtr(pl) ? readPtr(mem, pl + 216) : 0L;
        int clusterCnt = isPlausiblePtr(cluster) ? tarrayCount(mem, 40 + cluster) : -1;
        int levelsCnt = tarrayCount(mem, world + 432);
        int streamCnt = tarrayCount(mem, world + 216);
        Log.i(TAG, String.format("diag world=0x%x pl=0x%x own=0x%x cluster=0x%x actors=%d levels=%d stream=%d rich=0x%x", Long.valueOf(world), Long.valueOf(pl), Long.valueOf(owning), Long.valueOf(cluster), Integer.valueOf(clusterCnt), Integer.valueOf(levelsCnt), Integer.valueOf(streamCnt), Long.valueOf(sCachedRichLevel)));
    }

    private static void appendActorsFromTArray(ProcMemSession mem, long tarrayAddr, Set<Long> seen, List<Long> out) {
        long data = readPtr(mem, tarrayAddr);
        int count = mem.readI32(tarrayAddr + 8);
        if (!isPlausiblePtr(data) || count <= 0 || count > 8000) {
            return;
        }
        int limit = Math.min(count, 2048);
        for (int i = 0; i < limit; i++) {
            long actor = readPtr(mem, (((long) i) * 8) + data);
            if (isPlausiblePtr(actor) && seen.add(Long.valueOf(actor))) {
                out.add(Long.valueOf(actor));
            }
        }
    }

    private static long findUClass(ProcMemSession mem, long guObjAddr, int numElements, long gnamesPool, String shortName) {
        long j;
        long j2 = 0;
        if (!isPlausiblePtr(gnamesPool)) {
            return 0L;
        }
        int limit = Math.min(numElements, MAX_CLASS_SCAN);
        int i = 0;
        while (i < limit) {
            long obj = objectAt(mem, guObjAddr, numElements, i);
            if (!isPlausiblePtr(obj)) {
                j = j2;
            } else if (nameMatches(shortName, objectName(mem, gnamesPool, obj))) {
                long meta = readPtr(mem, 16 + obj);
                if (isPlausiblePtr(meta)) {
                    j = j2;
                    if ("Class".equals(objectName(mem, gnamesPool, meta))) {
                        return obj;
                    }
                } else {
                    j = j2;
                }
            } else {
                j = j2;
            }
            i++;
            j2 = j;
        }
        return j2;
    }

    static long resolveGNamesPool(ProcMemSession mem, long poolFromSlot, long globalSlotAddr) {
        if (sCachedGnamesPool != 0) {
            return sCachedGnamesPool;
        }
        if (isValidGNamesPool(mem, poolFromSlot)) {
            sCachedGnamesPool = poolFromSlot;
            Log.i(TAG, "GNames pool=deref 0x" + Long.toHexString(poolFromSlot));
            return poolFromSlot;
        }
        if (globalSlotAddr != 0 && globalSlotAddr != poolFromSlot && isValidGNamesPool(mem, globalSlotAddr)) {
            sCachedGnamesPool = globalSlotAddr;
            Log.i(TAG, "GNames pool=slot 0x" + Long.toHexString(globalSlotAddr));
            return globalSlotAddr;
        }
        if (!isPlausiblePtr(poolFromSlot)) {
            return 0L;
        }
        sCachedGnamesPool = poolFromSlot;
        return poolFromSlot;
    }

    private static boolean isValidGNamesPool(ProcMemSession mem, long pool) {
        if (isPlausiblePtr(pool) && isPlausiblePtr(readPtr(mem, pool))) {
            return probeNameIndices(mem, pool);
        }
        return false;
    }

    private static boolean probeNameIndices(ProcMemSession mem, long pool) {
        int[] iArr = {1, 2, 3, 4, 5, 10, 100, 500, 1000, 5000, BUserHandle.AID_APP_START};
        for (int i = 0; i < 11; i++) {
            int idx = iArr[i];
            if (!fnameCvBasic(mem, pool, idx).isEmpty()) {
                return true;
            }
        }
        return false;
    }

    private static boolean nameMatches(String want, String got) {
        if (got == null || got.isEmpty()) {
            return false;
        }
        return got.equals(want) || got.endsWith(want);
    }

    private static String fnameCvBasic(ProcMemSession mem, long gnames, int comparisonIndex) {
        byte[] lenBuf;
        int len;
        byte[] raw;
        if (!isPlausiblePtr(gnames) || comparisonIndex < 0) {
            return "";
        }
        long blocks = readPtr(mem, gnames);
        if (!isPlausiblePtr(blocks)) {
            return "";
        }
        int block = (comparisonIndex >> 16) & SupportMenu.USER_MASK;
        int offset = comparisonIndex & SupportMenu.USER_MASK;
        long blockEntry = readPtr(mem, (((long) block) * 8) + blocks);
        if (!isPlausiblePtr(blockEntry)) {
            return "";
        }
        long nameEntry = readPtr(mem, (((long) offset) * 16) + blockEntry);
        if (!isPlausiblePtr(nameEntry) || (lenBuf = mem.read(24 + nameEntry, 2)) == null || (len = (short) ((lenBuf[0] & UByte.MAX_VALUE) | ((lenBuf[1] & UByte.MAX_VALUE) << 8))) <= 0 || len > 1024 || (raw = mem.read(32 + nameEntry, len * 2)) == null || raw.length < 2) {
            return "";
        }
        int chars = Math.min(len, raw.length / 2);
        return new String(raw, 0, chars * 2, StandardCharsets.UTF_16LE);
    }

    private static boolean isGNamesAlive(ProcMemSession mem, long pool) {
        return isValidGNamesPool(mem, pool);
    }

    static String probeGNames(ProcMemSession mem, long poolPtr, long globalSlotAddr, long guObjAddr, int numElements) {
        long[] jArr;
        long[] jArr2 = {poolPtr, globalSlotAddr};
        int i = 0;
        for (int i2 = 2; i < i2; i2 = 2) {
            long pool = jArr2[i];
            if (isPlausiblePtr(pool)) {
                long resolved = resolveGNamesPool(mem, pool, globalSlotAddr);
                if (!isPlausiblePtr(resolved)) {
                    resolved = pool;
                }
                int[] iArr = {1, 2, 3, 100, 1000, 5000};
                for (int i3 = 0; i3 < 6; i3++) {
                    String n = fnameCvBasic(mem, resolved, iArr[i3]);
                    if (!n.isEmpty()) {
                        return n;
                    }
                }
                if (isPlausiblePtr(guObjAddr) && numElements > 0) {
                    int limit = Math.min(numElements, MaterialCardViewHelper.DEFAULT_FADE_ANIM_DURATION);
                    int i4 = 0;
                    while (i4 < limit) {
                        long obj = objectAt(mem, guObjAddr, numElements, i4);
                        if (isPlausiblePtr(obj)) {
                            jArr = jArr2;
                            int idx = mem.readI32(obj + 24) & Integer.MAX_VALUE;
                            String n2 = fnameCvBasic(mem, resolved, idx);
                            if (!n2.isEmpty()) {
                                return n2 + "@i" + idx;
                            }
                        } else {
                            jArr = jArr2;
                        }
                        i4++;
                        jArr2 = jArr;
                    }
                }
            }
            i++;
            jArr2 = jArr2;
        }
        return "empty";
    }

    private static String objectName(ProcMemSession mem, long gnamesPool, long obj) {
        if (!isPlausiblePtr(obj)) {
            return "";
        }
        int idx = mem.readI32(24 + obj) & Integer.MAX_VALUE;
        String n = fnameCvBasic(mem, gnamesPool, idx);
        if (n.isEmpty() && isPlausiblePtr(sGnamesGlobalSlot) && sGnamesGlobalSlot != gnamesPool) {
            return fnameCvBasic(mem, sGnamesGlobalSlot, idx);
        }
        return n;
    }

    private static String fnameToString(ProcMemSession mem, long namePool, int comparisonIndex) {
        return resolveFName(mem, namePool, comparisonIndex);
    }

    private static String resolveFName(ProcMemSession mem, long namePool, int comparisonIndex) {
        return fnameCvBasic(mem, namePool, comparisonIndex);
    }

    private static boolean isSubclassOf(ProcMemSession mem, long obj, long targetClass) {
        if (!isPlausiblePtr(obj) || !isPlausiblePtr(targetClass)) {
            return false;
        }
        long cls = readPtr(mem, 16 + obj);
        for (int depth = 0; isPlausiblePtr(cls) && depth < 24; depth++) {
            if (cls == targetClass) {
                return true;
            }
            cls = readPtr(mem, 48 + cls);
        }
        return false;
    }

    private static float[] readLocation(ProcMemSession mem, long actor) {
        byte[] loc;
        float[] out = new float[3];
        if (!isPlausiblePtr(actor)) {
            return out;
        }
        byte[] repl = mem.read(168 + actor, 12);
        if (repl != null) {
            float x = ProcMemHelper.readF32(repl, 0);
            float y = ProcMemHelper.readF32(repl, 4);
            float z = ProcMemHelper.readF32(repl, 8);
            if (hasNonTrivialPosition(new float[]{x, y, z})) {
                out[0] = x;
                out[1] = y;
                out[2] = z;
                return out;
            }
        }
        long root = readPtr(mem, 408 + actor);
        if (isPlausiblePtr(root) && (loc = mem.read(308 + root, 12)) != null) {
            float x2 = ProcMemHelper.readF32(loc, 0);
            float y2 = ProcMemHelper.readF32(loc, 4);
            float z2 = ProcMemHelper.readF32(loc, 8);
            if (isSanePosition(new float[]{x2, y2, z2})) {
                out[0] = x2;
                out[1] = y2;
                out[2] = z2;
            }
        }
        return out;
    }

    static boolean hasValidLocalPosition(ScanResult r) {
        float[] p = {r.localX, r.localY, r.localZ};
        return hasMapPosition(p);
    }

    private static float distanceMeters(float[] a, float[] b) {
        float dx = a[0] - b[0];
        float dy = a[1] - b[1];
        float dz = a[2] - b[2];
        return (float) (Math.sqrt(((dx * dx) + (dy * dy)) + (dz * dz)) / 100.0d);
    }

    private static long objectAt(ProcMemSession mem, long guObjAddr, int numElements, int index) {
        if (index < 0 || index >= numElements) {
            return 0L;
        }
        long objectsPtr = readPtr(mem, 16 + guObjAddr);
        if (!isPlausiblePtr(objectsPtr)) {
            return 0L;
        }
        int chunkIdx = index / 65536;
        int inChunk = index % 65536;
        long chunk = readPtr(mem, (((long) chunkIdx) * 8) + objectsPtr);
        if (!isPlausiblePtr(chunk)) {
            return 0L;
        }
        return readPtr(mem, (((long) inChunk) * 24) + chunk);
    }

    private static long readPtr(ProcMemSession mem, long addr) {
        if (!isPlausiblePtr(addr)) {
            return 0L;
        }
        long p = mem.readU64(addr);
        if (isPlausiblePtr(p)) {
            return p;
        }
        return 0L;
    }

    static long resolveGuObjectAddr(ProcMemSession mem, long ue4Base, long defaultAddr) {
        int n;
        long indirect = readPtr(mem, defaultAddr);
        if (isPlausiblePtr(indirect) && (n = mem.readI32(36 + indirect)) > 1000 && n < 500000) {
            return indirect;
        }
        return defaultAddr;
    }

    static int countValidObjects(ProcMemSession mem, long guObjAddr, int numElements, int max) {
        int n = Math.min(numElements, max);
        int valid = 0;
        for (int i = 0; i < n; i++) {
            if (isPlausiblePtr(objectAt(mem, guObjAddr, numElements, i))) {
                valid++;
            }
        }
        return valid;
    }

    static boolean isPlausiblePtr(long p) {
        return p >= PTR_MIN && p <= PTR_MAX;
    }
}
