package top.niunaijun.blackboxa.patch;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;
import com.topjohnwu.superuser.Shell;
import java.io.IOException;
import java.io.RandomAccessFile;
import kotlin.UByte;
import top.niunaijun.blackbox.core.system.JarConfig;
import top.niunaijun.blackboxa.util.AppLog;

/* JADX INFO: loaded from: classes11.dex */
public final class LibAnogsPatcher {
    private static final boolean ENABLE_LOADER_PATCH = false;
    private static final String LIB_TERSAFE = "libtersafe.so";
    private static final int MAX_WAIT_MS = 300000;
    private static final Patch[] PATCHES_TERSAFE = {patch(1311312, "00 00 80 D2 C0 03 5F D6")};
    private static final int PATCH_DELAY_MS = 5000;
    private static final int POLL_MS = 500;
    private static final String TAG = "TERSAFE_PATCH";
    private static volatile boolean patchApplied;
    private static volatile boolean workerRunning;

    private LibAnogsPatcher() {
    }

    public static void resetSession() {
        patchApplied = false;
        AppLog.i(TAG, "resetSession");
    }

    public static void startOnGameLaunch(Context context) {
    }

    private static /* synthetic */ void lambda$startOnGameLaunch$0(Context app) {
        try {
            waitAndPatch(app);
        } finally {
            workerRunning = false;
            AppLog.i(TAG, "worker finished applied=" + patchApplied);
        }
    }

    private static void waitAndPatch(Context ctx) {
        boolean libsReady;
        long jCurrentTimeMillis = System.currentTimeMillis();
        long j = JarConfig.CACHE_CLEANUP_INTERVAL_MS;
        long deadline = jCurrentTimeMillis + JarConfig.CACHE_CLEANUP_INTERVAL_MS;
        boolean libsReady2 = false;
        long readyAt = 0;
        int poll = 0;
        AppLog.i(TAG, "waitAndPatch started deadlineMs=300000");
        while (!patchApplied && System.currentTimeMillis() < deadline) {
            poll++;
            int pid = GamePidHelper.findPidWithReadyLibs(ctx);
            if (poll % 10 == 1) {
                AppLog.d(TAG, "poll#" + poll + " pid=" + pid + " libsReady=" + libsReady2 + " elapsedMs=" + (System.currentTimeMillis() - (deadline - j)));
            }
            if (pid >= 10) {
                long tersafeBase = GamePidHelper.findLibBase(pid, LIB_TERSAFE);
                if (tersafeBase != 0) {
                    if (!libsReady2) {
                        libsReady2 = true;
                        readyAt = System.currentTimeMillis();
                        AppLog.i(TAG, "libtersafe ready pid=" + pid + " base=0x" + Long.toHexString(tersafeBase) + " waiting " + PATCH_DELAY_MS + "ms");
                    }
                    long waited = System.currentTimeMillis() - readyAt;
                    if (waited >= 5000) {
                        AppLog.i(TAG, "applying patches pid=" + pid + " afterWaitMs=" + waited);
                        if (applyPatches(pid, tersafeBase)) {
                            patchApplied = true;
                            AppLog.i(TAG, "SUCCESS — libtersafe x" + PATCHES_TERSAFE.length);
                            showToast(ctx, "Bypass OK — libtersafe x" + PATCHES_TERSAFE.length);
                            return;
                        }
                        AppLog.e(TAG, "applyPatches failed pid=" + pid);
                    }
                }
                libsReady = libsReady2;
            } else {
                if (libsReady2) {
                    AppLog.w(TAG, "lost pid/libs during wait");
                }
                libsReady = false;
            }
            try {
                Thread.sleep(500L);
                libsReady2 = libsReady;
                j = JarConfig.CACHE_CLEANUP_INTERVAL_MS;
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                AppLog.w(TAG, "interrupted");
                return;
            }
        }
        boolean libsReady3 = patchApplied;
        if (!libsReady3) {
            AppLog.e(TAG, "TIMEOUT — libtersafe not patched");
            showToast(ctx, "Bypass Timeout (libtersafe?)");
        }
    }

    private static void showToast(final Context ctx, final String message) {
        new Handler(Looper.getMainLooper()).post(new Runnable() { // from class: top.niunaijun.blackboxa.patch.LibAnogsPatcher$$ExternalSyntheticLambda0
            @Override // java.lang.Runnable
            public final void run() {
                Toast.makeText(ctx, message, 1).show();
            }
        });
    }

    private static boolean applyPatches(int pid, long tersafeBase) {
        for (Patch p : PATCHES_TERSAFE) {
            long addr = p.offset + tersafeBase;
            AppLog.i(TAG, String.format("patch offset=0x%X addr=0x%X bytes=%d", Long.valueOf(p.offset), Long.valueOf(addr), Integer.valueOf(p.bytes.length)));
            if (!writePatch(pid, addr, p.bytes)) {
                AppLog.e(TAG, "writePatch FAILED addr=0x" + Long.toHexString(addr));
                return false;
            }
            AppLog.i(TAG, "writePatch OK addr=0x" + Long.toHexString(addr));
        }
        return true;
    }

    private static boolean writePatch(int pid, long address, byte[] bytes) {
        if (writeProcMem(pid, address, bytes)) {
            AppLog.d(TAG, "writeProcMem direct OK");
            return true;
        }
        AppLog.d(TAG, "writeProcMem direct failed, trying su");
        if (Shell.rootAccess()) {
            boolean ok = writeProcMemAsRoot(pid, address, bytes);
            AppLog.d(TAG, "writeProcMemAsRoot => " + ok);
            return ok;
        }
        AppLog.e(TAG, "no root access");
        return false;
    }

    private static boolean writeProcMem(int pid, long address, byte[] bytes) {
        String path = "/proc/" + pid + "/mem";
        try {
            RandomAccessFile mem = new RandomAccessFile(path, "rw");
            try {
                mem.seek(address);
                mem.write(bytes);
                mem.close();
                return true;
            } finally {
            }
        } catch (IOException e) {
            AppLog.d(TAG, "writeProcMem: " + e.getMessage());
            return false;
        }
    }

    private static boolean writeProcMemAsRoot(int pid, long address, byte[] bytes) {
        StringBuilder printf = new StringBuilder("printf '");
        for (byte b : bytes) {
            printf.append(String.format("\\x%02x", Integer.valueOf(b & UByte.MAX_VALUE)));
        }
        printf.append("' | dd of=/proc/").append(pid).append("/mem bs=1 seek=").append(address).append(" count=").append(bytes.length).append(" conv=notrunc 2>/dev/null");
        Shell.Result r = Shell.su(printf.toString()).exec();
        if (!r.isSuccess()) {
            AppLog.e(TAG, "su dd failed: " + r.getErr());
        }
        return r.isSuccess();
    }

    private static Patch patch(long offset, String hex) {
        return new Patch(offset, parseHex(hex));
    }

    private static byte[] parseHex(String hex) {
        String[] parts = hex.trim().split("\\s+");
        byte[] out = new byte[parts.length];
        for (int i = 0; i < parts.length; i++) {
            out[i] = (byte) Integer.parseInt(parts[i], 16);
        }
        return out;
    }

    private static final class Patch {
        final byte[] bytes;
        final long offset;

        Patch(long offset, byte[] bytes) {
            this.offset = offset;
            this.bytes = bytes;
        }
    }
}
