package top.niunaijun.blackboxa.esp;

/* JADX INFO: loaded from: classes11.dex */
public final class EspAimSettings {
    public static final boolean FEATURE_ENABLED = false;
    public static volatile boolean enabled;
    public static volatile int fovRadius = 120;
    public static volatile int smooth = 8;
    public static volatile int aimSpeed = 20;
    public static volatile float touchX = 900.0f;
    public static volatile float touchY = 540.0f;
    public static volatile int trigger = 0;

    private EspAimSettings() {
    }

    public static void applyToNative() {
        enabled = false;
        try {
            EspOverlayService.nativeSetEspAimConfig(enabled, fovRadius, 200.0f, smooth, aimSpeed, touchX, touchY, trigger);
        } catch (Throwable th) {
        }
    }
}
