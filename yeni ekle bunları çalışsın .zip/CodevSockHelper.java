package top.niunaijun.blackboxa.esp;

import android.content.Context;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import top.niunaijun.blackboxa.util.AppLog;

/* JADX INFO: loaded from: classes11.dex */
final class CodevSockHelper {
    private static final String BUILD_FILE = "codev_sock.build";
    static final int SOCK_BUILD = 59;
    private static final String SOCK_NAME = "codev_sock";
    private static final String TAG = "BYSTOM_ESP";

    private CodevSockHelper() {
    }

    /* JADX WARN: Removed duplicated region for block: B:50:0x00af A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    static java.io.File ensureInstalled(android.content.Context r13) {
        /*
            Method dump skipped, instruction units count: 201
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: top.niunaijun.blackboxa.esp.CodevSockHelper.ensureInstalled(android.content.Context):java.io.File");
    }

    private static int readBuild(Context app) {
        File f = new File(app.getFilesDir(), BUILD_FILE);
        if (!f.exists()) {
            return -1;
        }
        byte[] buf = new byte[16];
        try {
            FileInputStream fis = new FileInputStream(f);
            try {
                int n = fis.read(buf);
                if (n > 0) {
                    int i = Integer.parseInt(new String(buf, 0, n, StandardCharsets.UTF_8).trim());
                    fis.close();
                    return i;
                }
                fis.close();
                return -1;
            } finally {
            }
        } catch (Exception e) {
            return -1;
        }
        return -1;
    }

    private static void writeBuild(Context app, int build) {
        File f = new File(app.getFilesDir(), BUILD_FILE);
        try {
            FileOutputStream fos = new FileOutputStream(f, false);
            try {
                fos.write(String.valueOf(build).getBytes(StandardCharsets.UTF_8));
                fos.close();
            } finally {
            }
        } catch (IOException e) {
            AppLog.w(TAG, "codev_sock build stamp failed", e);
        }
    }
}
