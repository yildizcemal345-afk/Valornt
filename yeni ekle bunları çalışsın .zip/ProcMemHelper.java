package top.niunaijun.blackboxa.patch;

import java.io.IOException;
import java.io.RandomAccessFile;
import kotlin.UByte;

/* JADX INFO: loaded from: classes11.dex */
public final class ProcMemHelper {
    private ProcMemHelper() {
    }

    public static byte[] read(int pid, long address, int length) {
        if (pid < 10 || length <= 0 || length > 4096 || address < 4294967296L) {
            return null;
        }
        byte[] buf = new byte[length];
        String path = "/proc/" + pid + "/mem";
        try {
            RandomAccessFile mem = new RandomAccessFile(path, "r");
            try {
                mem.seek(address);
                int total = 0;
                while (total < length) {
                    int n = mem.read(buf, total, length - total);
                    if (n >= 0) {
                        total += n;
                    } else {
                        mem.close();
                        return null;
                    }
                }
                mem.close();
                return buf;
            } finally {
            }
        } catch (IOException e) {
            return null;
        }
    }

    public static long readU64(byte[] data, int offset) {
        if (data == null || offset < 0 || offset + 8 > data.length) {
            return 0L;
        }
        return (((long) data[offset]) & 255) | ((((long) data[offset + 1]) & 255) << 8) | ((((long) data[offset + 2]) & 255) << 16) | ((((long) data[offset + 3]) & 255) << 24) | ((((long) data[offset + 4]) & 255) << 32) | ((((long) data[offset + 5]) & 255) << 40) | ((((long) data[offset + 6]) & 255) << 48) | ((255 & ((long) data[offset + 7])) << 56);
    }

    public static int readI32(byte[] data, int offset) {
        if (data == null || offset < 0 || offset + 4 > data.length) {
            return 0;
        }
        return (data[offset] & UByte.MAX_VALUE) | ((data[offset + 1] & UByte.MAX_VALUE) << 8) | ((data[offset + 2] & UByte.MAX_VALUE) << 16) | ((data[offset + 3] & UByte.MAX_VALUE) << 24);
    }

    public static float readF32(byte[] data, int offset) {
        return Float.intBitsToFloat(readI32(data, offset));
    }
}
