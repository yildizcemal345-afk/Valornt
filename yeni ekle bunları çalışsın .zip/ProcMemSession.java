package top.niunaijun.blackboxa.patch;

import java.io.IOException;
import java.io.RandomAccessFile;

/* JADX INFO: loaded from: classes11.dex */
final class ProcMemSession implements AutoCloseable {
    private final RandomAccessFile mem;
    private final int pid;

    private ProcMemSession(int pid, RandomAccessFile mem) {
        this.pid = pid;
        this.mem = mem;
    }

    static ProcMemSession open(int pid) {
        if (pid < 10) {
            return null;
        }
        try {
            return new ProcMemSession(pid, new RandomAccessFile("/proc/" + pid + "/mem", "r"));
        } catch (IOException e) {
            return null;
        }
    }

    int pid() {
        return this.pid;
    }

    byte[] read(long address, int length) {
        if (this.mem == null || length <= 0 || length > 4096 || address < 4294967296L) {
            return null;
        }
        byte[] buf = new byte[length];
        try {
            this.mem.seek(address);
            int total = 0;
            while (total < length) {
                int n = this.mem.read(buf, total, length - total);
                if (n < 0) {
                    return null;
                }
                total += n;
            }
            return buf;
        } catch (IOException e) {
            return null;
        }
    }

    long readU64(long address) {
        byte[] b = read(address, 8);
        if (b != null) {
            return ProcMemHelper.readU64(b, 0);
        }
        return 0L;
    }

    int readI32(long address) {
        byte[] b = read(address, 4);
        if (b != null) {
            return ProcMemHelper.readI32(b, 0);
        }
        return 0;
    }

    @Override // java.lang.AutoCloseable
    public void close() {
        if (this.mem != null) {
            try {
                this.mem.close();
            } catch (IOException e) {
            }
        }
    }
}
