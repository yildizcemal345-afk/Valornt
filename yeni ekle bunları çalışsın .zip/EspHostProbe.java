package top.niunaijun.blackboxa.patch;

import android.content.Context;
import android.util.Log;
import androidx.vectordrawable.graphics.drawable.PathInterpolatorCompat;

/* JADX INFO: loaded from: classes11.dex */
public final class EspHostProbe {
    private static final boolean ENABLE_HOST_PROBE = false;
    private static final long GNames_OFFSET = 185086992;
    private static final long GUObject_NumElements_OFF = 36;
    private static final long GUObject_OFFSET = 185118736;
    private static final String LIB_UE4 = "libUE4.so";
    private static final int MAX_PROBES = 180;
    private static final int MAX_WAIT_MS = 900000;
    private static final int POLL_MS = 500;
    private static final int PROBE_INTERVAL_MS = 12000;
    private static final int START_DELAY_MS = 20000;
    private static final String TAG = "BYSTOM_ESP";
    private static volatile boolean workerRunning;

    private EspHostProbe() {
    }

    public static void ensureRunning(Context context) {
    }

    private static /* synthetic */ void lambda$ensureRunning$0(Context context) {
        try {
            runProbe(context.getApplicationContext());
        } finally {
            try {
            } finally {
            }
        }
    }

    public static void startOnGameLaunch(Context context) {
        Log.i(TAG, "startOnGameLaunch");
        ensureRunning(context);
    }

    private static void runProbe(Context ctx) throws Throwable {
        int i;
        long j;
        long deadline;
        long deadline2 = System.currentTimeMillis() + 900000;
        int pid = -1;
        long ue4Base = 0;
        long readyAt = 0;
        long lastHeartbeat = 0;
        while (true) {
            i = 10;
            if (System.currentTimeMillis() >= deadline2) {
                j = 0;
                break;
            }
            int resolved = GamePidHelper.resolveGamePid();
            if (resolved >= 10) {
                pid = resolved;
                ue4Base = GamePidHelper.findLibBase(pid, LIB_UE4);
                if (ue4Base != 0) {
                    if (readyAt != 0) {
                        j = 0;
                    } else {
                        readyAt = System.currentTimeMillis();
                        j = 0;
                        Log.i(TAG, "UE4 ready pid=" + pid + " base=0x" + Long.toHexString(ue4Base) + " waiting 20000ms");
                    }
                    if (System.currentTimeMillis() - readyAt >= 20000) {
                        break;
                    }
                } else {
                    j = 0;
                }
            } else {
                j = 0;
                readyAt = 0;
                ue4Base = 0;
                pid = -1;
            }
            long now = System.currentTimeMillis();
            if (now - lastHeartbeat >= 3000) {
                lastHeartbeat = now;
                if (pid >= 10 && ue4Base != j) {
                    Log.i(TAG, "wait: pid=" + pid + " UE4 ok, delay " + (20000 - (now - readyAt)) + "ms left");
                } else if (pid >= 10) {
                    Log.i(TAG, "wait: pid=" + pid + " loading (no libUE4 yet)");
                } else {
                    Log.i(TAG, "wait: no game pid — launch CodeV from BlackBox");
                }
            }
            sleep(POLL_MS);
        }
        if (pid < 10 || ue4Base == j) {
            Log.w(TAG, "host probe timeout — no UE4");
            return;
        }
        Ue4HostScanner.resetCache(pid);
        int noGameStreak = 0;
        int n = 1;
        while (n <= MAX_PROBES) {
            int resolved2 = GamePidHelper.resolveGamePid();
            if (resolved2 < i || !GamePidHelper.shouldSwitchPid(pid, resolved2)) {
                deadline = deadline2;
                if (GamePidHelper.isProcessPresent(pid)) {
                    noGameStreak = 0;
                } else {
                    if (!GamePidHelper.isProcessPresent(pid)) {
                        int ue4Pid = GamePidHelper.resolveGamePid();
                        if (ue4Pid >= 10 && GamePidHelper.hasUe4Loaded(ue4Pid)) {
                            Log.i(TAG, "#" + n + " reattach pid=" + ue4Pid);
                            Ue4HostScanner.resetCache(ue4Pid);
                            noGameStreak = 0;
                            pid = ue4Pid;
                        } else {
                            noGameStreak++;
                            if (noGameStreak >= 60) {
                                Log.w(TAG, "#" + n + " no game process — stop");
                                return;
                            }
                            if (noGameStreak == 1 || noGameStreak % 5 == 0) {
                                Log.i(TAG, "#" + n + " waiting game process...");
                            }
                            sleep(2000);
                        }
                    }
                    n++;
                    deadline2 = deadline;
                    i = 10;
                }
            } else {
                deadline = deadline2;
                Log.i(TAG, "#" + n + " pid " + pid + " -> " + resolved2 + " (libUE4)");
                pid = resolved2;
                Ue4HostScanner.resetCache(pid);
                noGameStreak = 0;
            }
            long base = pid >= 10 ? GamePidHelper.findLibBase(pid, LIB_UE4) : j;
            if (base == j) {
                if (GamePidHelper.isProcessPresent(pid)) {
                    if (n == 1 || n % 4 == 0) {
                        Log.i(TAG, "#" + n + " UE4 reloading pid=" + pid + " (training load?)");
                    }
                    ue4Base = 0;
                    sleep(PathInterpolatorCompat.MAX_NUM_POINTS);
                } else {
                    if (n == 1 || n % 8 == 0) {
                        Log.i(TAG, "#" + n + " loading — game pid=" + pid + " (need libUE4.so mapped)");
                    }
                    ue4Base = 0;
                    sleep(2000);
                }
            } else {
                if (base != ue4Base) {
                    Log.i(TAG, "#" + n + " UE4 ready base=0x" + Long.toHexString(base));
                }
                ue4Base = base;
                probeOnce(n, pid, ue4Base);
                sleep(PROBE_INTERVAL_MS);
            }
            n++;
            deadline2 = deadline;
            i = 10;
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:170:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:19:0x004e  */
    /* JADX WARN: Removed duplicated region for block: B:47:0x00ce  */
    /* JADX WARN: Removed duplicated region for block: B:81:0x01f7  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static void probeOnce(int r47, int r48, long r49) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 1088
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: top.niunaijun.blackboxa.patch.EspHostProbe.probeOnce(int, int, long):void");
    }

    private static void sleep(int ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
