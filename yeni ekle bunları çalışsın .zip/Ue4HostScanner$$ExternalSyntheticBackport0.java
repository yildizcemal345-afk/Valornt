package top.niunaijun.blackboxa.patch;

/* JADX INFO: compiled from: D8$$SyntheticClass */
/* JADX INFO: loaded from: classes11.dex */
public final /* synthetic */ class Ue4HostScanner$$ExternalSyntheticBackport0 {
    public static /* synthetic */ boolean m(float f) {
        return (Float.isInfinite(f) || Float.isNaN(f)) ? false : true;
    }
}
