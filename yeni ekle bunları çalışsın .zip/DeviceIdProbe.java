package top.niunaijun.blackboxa.patch;

import android.content.Context;
import android.os.Build;
import android.os.Process;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.util.Log;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import top.niunaijun.blackbox.BlackBoxCore;
import top.niunaijun.blackbox.app.BActivityThread;

/* JADX INFO: loaded from: classes11.dex */
public final class DeviceIdProbe {
    private static final String CODEV = "com.tencent.tmgp.codev";
    private static final String[] LEAK_MARKERS = {"POCO", "poco", "duchamp", "2311DRK48I", "mt6897", "Xiaomi", "xiaomi", "Redmi", "redmi"};
    public static final String TAG = "BYSTOM_DEVICE_ID";
    private static volatile boolean sGuestLogged;

    private DeviceIdProbe() {
    }

    public static void logHostOnLaunch(Context context) {
        if (context == null) {
            return;
        }
        log(context, "HOST_LOADER", null, null);
    }

    public static void logGuestOnGameStart(Context context, String packageName, String processName) {
        if (context == null || packageName == null || !CODEV.equals(packageName)) {
            return;
        }
        if ((processName != null && !processName.equals(packageName)) || sGuestLogged) {
            return;
        }
        sGuestLogged = true;
        log(context, "GUEST_GAME", packageName, processName);
    }

    private static void log(Context context, String where, String packageName, String processName) {
        try {
            Context app = context.getApplicationContext();
            String pkg = packageName != null ? packageName : app.getPackageName();
            String proc = processName;
            String hostPkg = "?";
            if (proc == null) {
                try {
                    proc = BActivityThread.getAppProcessName();
                } catch (Throwable th) {
                    proc = "?";
                }
            }
            String androidId = Settings.Secure.getString(app.getContentResolver(), "android_id");
            try {
                hostPkg = BlackBoxCore.getHostPkg();
            } catch (Throwable th2) {
            }
            Log.i(TAG, "===== " + where + " =====");
            Log.i(TAG, "pkg=" + pkg + " proc=" + proc + " hostPkg=" + hostPkg + " pid=" + Process.myPid());
            logConfigured(where);
            Log.i(TAG, "[JAVA Build] android_id=" + safe(androidId));
            Log.i(TAG, "[JAVA Build] fingerprint=" + safe(Build.FINGERPRINT));
            Log.i(TAG, "[JAVA Build] serial=" + safe(Build.SERIAL));
            Log.i(TAG, "[JAVA Build] model=" + safe(Build.MODEL) + " brand=" + safe(Build.BRAND) + " device=" + safe(Build.DEVICE) + " manufacturer=" + safe(Build.MANUFACTURER));
            Log.i(TAG, "[JAVA Build] hardware=" + safe(Build.HARDWARE) + " product=" + safe(Build.PRODUCT) + " board=" + safe(Build.BOARD) + " display=" + safe(Build.DISPLAY));
            logSystemProperty("ro.product.model");
            logSystemProperty("ro.product.brand");
            logSystemProperty("ro.product.manufacturer");
            logSystemProperty("ro.product.device");
            logSystemProperty("ro.product.name");
            logSystemProperty("ro.product.board");
            logSystemProperty("ro.build.fingerprint");
            logSystemProperty("ro.hardware");
            logSystemProperty("ro.boot.hardware");
            logSystemProperty("ro.serialno");
            try {
                TelephonyManager tm = (TelephonyManager) app.getSystemService("phone");
                if (tm != null) {
                    String imei = null;
                    if (Build.VERSION.SDK_INT >= 26) {
                        try {
                            imei = tm.getImei();
                        } catch (Throwable th3) {
                        }
                    }
                    if (imei == null) {
                        try {
                            String legacy = tm.getDeviceId();
                            imei = legacy;
                        } catch (Throwable th4) {
                        }
                    }
                    Log.i(TAG, "[JAVA Telephony] imei=" + safe(imei));
                }
            } catch (Throwable t) {
                Log.i(TAG, "[JAVA Telephony] imei=(unavailable) " + t.getMessage());
            }
            if ("GUEST_GAME".equals(where)) {
                printVerdict(androidId);
            }
            Log.i(TAG, "===== end " + where + " =====");
        } catch (Throwable t2) {
            Log.e(TAG, where + " probe failed", t2);
        }
    }

    private static void logConfigured(String where) {
        try {
            Log.i(TAG, "[CONFIG saved] android_id=" + safe(BlackBoxCore.getCustomAndroidId()) + " imei=" + safe(BlackBoxCore.getCustomImei()) + " serial=" + safe(BlackBoxCore.getCustomSerial()) + " model=" + safe(BlackBoxCore.getCustomModel()));
        } catch (Throwable th) {
            Log.i(TAG, "[CONFIG saved] (unavailable in " + where + ")");
        }
    }

    private static void logSystemProperty(String key) {
        String value = getSystemProperty(key);
        Log.i(TAG, "[NATIVE SystemProperties] " + key + "=" + safe(value));
    }

    private static String getSystemProperty(String key) {
        try {
            Class<?> clazz = Class.forName("android.os.SystemProperties");
            Method get = clazz.getMethod("get", String.class, String.class);
            return (String) get.invoke(null, key, "");
        } catch (Throwable t) {
            return "(error:" + t.getMessage() + ")";
        }
    }

    private static void printVerdict(String androidId) {
        List<String> leaks = new ArrayList<>();
        collectLeak(leaks, "Build.MODEL", Build.MODEL);
        collectLeak(leaks, "Build.BRAND", Build.BRAND);
        collectLeak(leaks, "Build.FINGERPRINT", Build.FINGERPRINT);
        collectLeak(leaks, "Build.HARDWARE", Build.HARDWARE);
        collectLeak(leaks, "Build.MANUFACTURER", Build.MANUFACTURER);
        collectLeak(leaks, "ro.product.model", getSystemProperty("ro.product.model"));
        collectLeak(leaks, "ro.product.brand", getSystemProperty("ro.product.brand"));
        collectLeak(leaks, "ro.build.fingerprint", getSystemProperty("ro.build.fingerprint"));
        collectLeak(leaks, "ro.hardware", getSystemProperty("ro.hardware"));
        if (leaks.isEmpty()) {
            Log.i(TAG, ">>> VERDICT: SPOOF_OK — game process sees spoofed profile, no POCO leak detected <<<");
        } else {
            Log.e(TAG, ">>> VERDICT: LEAK_DETECTED — real device data visible to game <<<");
            for (String leak : leaks) {
                Log.e(TAG, "  LEAK: " + leak);
            }
        }
        String configuredId = null;
        try {
            configuredId = BlackBoxCore.getCustomAndroidId();
        } catch (Throwable th) {
        }
        if (configuredId != null && !configuredId.isEmpty() && androidId != null && !configuredId.equalsIgnoreCase(androidId)) {
            Log.w(TAG, ">>> WARN: android_id mismatch config=" + configuredId + " read=" + androidId);
        } else if (configuredId != null && !configuredId.isEmpty()) {
            Log.i(TAG, ">>> android_id matches config <<<");
        }
    }

    private static void collectLeak(List<String> leaks, String field, String value) {
        if (value == null || value.isEmpty()) {
            return;
        }
        String lower = value.toLowerCase(Locale.US);
        for (String marker : LEAK_MARKERS) {
            if (lower.contains(marker.toLowerCase(Locale.US))) {
                leaks.add(field + "=" + value);
                return;
            }
        }
    }

    private static String safe(String s) {
        return (s == null || s.isEmpty()) ? "(empty)" : s;
    }
}
