package top.niunaijun.blackboxa.esp;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.Choreographer;
import android.view.View;

/* JADX INFO: loaded from: classes11.dex */
public final class EspCanvasView extends View {
    private static final long TARGET_FRAME_NS = 16666667;
    private final Context appContext;
    private final Paint boxPaint;
    private final Choreographer choreographer;
    private final Paint fillPaint;
    private final Choreographer.FrameCallback frameCallback;
    private final Paint skelPaint;
    private final Paint textPaint;
    private final Handler uiHandler;
    private volatile int viewHeight;
    private volatile int viewWidth;

    public EspCanvasView(Context context) {
        super(context);
        this.boxPaint = new Paint(1);
        this.textPaint = new Paint(1);
        this.fillPaint = new Paint(1);
        this.skelPaint = new Paint(1);
        this.uiHandler = new Handler(Looper.getMainLooper());
        this.choreographer = Choreographer.getInstance();
        this.frameCallback = new Choreographer.FrameCallback() { // from class: top.niunaijun.blackboxa.esp.EspCanvasView.1
            private long lastFrameNs;

            @Override // android.view.Choreographer.FrameCallback
            public void doFrame(long frameTimeNanos) {
                if (!EspCanvasView.this.isAttachedToWindow()) {
                    return;
                }
                if (this.lastFrameNs == 0 || frameTimeNanos - this.lastFrameNs >= EspCanvasView.TARGET_FRAME_NS) {
                    this.lastFrameNs = frameTimeNanos;
                    EspCanvasView.this.invalidate();
                }
                EspCanvasView.this.choreographer.postFrameCallback(this);
            }
        };
        this.appContext = context.getApplicationContext();
        this.boxPaint.setStyle(Paint.Style.STROKE);
        this.boxPaint.setStrokeWidth(2.0f);
        this.boxPaint.setFilterBitmap(true);
        this.textPaint.setColor(-1);
        this.textPaint.setTextSize(28.0f);
        setFocusableInTouchMode(false);
        setBackgroundColor(0);
        setLayerType(2, null);
    }

    @Override // android.view.View
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.choreographer.postFrameCallback(this.frameCallback);
    }

    @Override // android.view.View
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        this.viewWidth = w;
        this.viewHeight = h;
    }

    @Override // android.view.View
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int w = getWidth();
        int h = getHeight();
        if (w <= 0 || h <= 0) {
            DisplayMetrics dm = this.appContext.getResources().getDisplayMetrics();
            w = dm.widthPixels;
            h = dm.heightPixels;
        }
        if (w > 0 && h > 0) {
            EspOverlayService.DrawOn(this, canvas, w, h);
        }
    }

    @Override // android.view.View
    protected void onDetachedFromWindow() {
        this.choreographer.removeFrameCallback(this.frameCallback);
        super.onDetachedFromWindow();
    }

    public void drawEspFilledRect(Canvas canvas, int color, float left, float top2, float right, float bottom) {
        this.fillPaint.setStyle(Paint.Style.FILL);
        this.fillPaint.setColor(color);
        canvas.drawRect(left, top2, right, bottom, this.fillPaint);
    }

    public void drawEspRect(Canvas canvas, int color, float left, float top2, float right, float bottom) {
        this.boxPaint.setColor(color);
        canvas.drawRect(left, top2, right, bottom, this.boxPaint);
    }

    public void drawEspCornerBox(Canvas canvas, int color, float left, float top2, float right, float bottom) {
        this.boxPaint.setColor(color);
        this.boxPaint.setStyle(Paint.Style.STROKE);
        this.boxPaint.setStrokeWidth(6.0f);
        float w = right - left;
        float h = bottom - top2;
        float corner = Math.max(10.0f, Math.min(w, h) * 0.22f);
        canvas.drawLine(left, top2, left + corner, top2, this.boxPaint);
        canvas.drawLine(left, top2, left, top2 + corner, this.boxPaint);
        canvas.drawLine(right, top2, right - corner, top2, this.boxPaint);
        canvas.drawLine(right, top2, right, top2 + corner, this.boxPaint);
        canvas.drawLine(left, bottom, left + corner, bottom, this.boxPaint);
        canvas.drawLine(left, bottom, left, bottom - corner, this.boxPaint);
        canvas.drawLine(right, bottom, right - corner, bottom, this.boxPaint);
        canvas.drawLine(right, bottom, right, bottom - corner, this.boxPaint);
    }

    public void drawEspLine(Canvas canvas, int color, float x1, float y1, float x2, float y2) {
        this.boxPaint.setColor(color);
        this.boxPaint.setStrokeWidth(3.0f);
        canvas.drawLine(x1, y1, x2, y2, this.boxPaint);
    }

    public void drawEspSkeletonLine(Canvas canvas, int color, float x1, float y1, float x2, float y2) {
        this.skelPaint.setColor(color);
        this.skelPaint.setStrokeWidth(5.0f);
        this.skelPaint.setStyle(Paint.Style.STROKE);
        canvas.drawLine(x1, y1, x2, y2, this.skelPaint);
    }

    public void drawEspCircle(Canvas canvas, int color, float cx, float cy, float radius) {
        this.boxPaint.setColor(color);
        this.boxPaint.setStyle(Paint.Style.STROKE);
        this.boxPaint.setStrokeWidth(2.0f);
        canvas.drawCircle(cx, cy, radius, this.boxPaint);
    }

    public void drawEspTextCentered(Canvas canvas, int color, String text, float centerX, float baselineY, float size) {
        this.textPaint.setColor(color);
        this.textPaint.setTextSize(size);
        float tw = this.textPaint.measureText(text);
        canvas.drawText(text, centerX - (0.5f * tw), baselineY, this.textPaint);
    }

    public void drawEspText(Canvas canvas, int color, String text, float x, float y, float size) {
        this.textPaint.setColor(color);
        this.textPaint.setTextSize(size);
        canvas.drawText(text, x, y, this.textPaint);
    }

    public void stop() {
        this.choreographer.removeFrameCallback(this.frameCallback);
    }
}
