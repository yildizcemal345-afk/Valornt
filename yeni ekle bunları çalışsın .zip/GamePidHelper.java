package top.niunaijun.blackboxa.patch;

import android.content.Context;
import androidx.recyclerview.widget.ItemTouchHelper;
import com.topjohnwu.superuser.Shell;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.function.IntPredicate;
import top.niunaijun.blackboxa.util.AppLog;

/* JADX INFO: loaded from: classes11.dex */
public final class GamePidHelper {
    private static final String GAME_PACKAGE = "com.tencent.tmgp.codev";
    private static final String LIB_TERSAFE = "libtersafe.so";
    private static final String LIB_UE4 = "libUE4.so";
    private static final String TAG = "TERSAFE_PATCH";
    private static int sLastLoggedPid = -1;
    private static volatile boolean sRefreshRunning;
    private static volatile Thread sRefreshThread;

    private GamePidHelper() {
    }

    public static int findGamePid() {
        return resolveGamePid();
    }

    public static int resolveGamePid() {
        int ue4Pid = findBestGamePid(false, true);
        if (ue4Pid >= 10) {
            return ue4Pid;
        }
        return findBestGamePid(false, false);
    }

    public static boolean shouldSwitchPid(int current, int candidate) {
        if (candidate < 10 || !hasUe4Loaded(candidate)) {
            return false;
        }
        if (current >= 10 && isProcessPresent(current) && hasUe4Loaded(current)) {
            return false;
        }
        return true;
    }

    public static boolean isProcessAlive(int pid) {
        return isProcessPresent(pid) && hasUe4Loaded(pid);
    }

    public static boolean isProcessPresent(int pid) {
        return pid >= 10 && new File(new StringBuilder().append("/proc/").append(pid).toString()).isDirectory();
    }

    public static boolean hasUe4Loaded(int pid) {
        return findLibBase(pid, LIB_UE4) != 0;
    }

    public static int findPidWithReadyLibs(Context ctx) {
        if (ctx == null) {
            AppLog.w(TAG, "findPidWithReadyLibs: context null");
            return -1;
        }
        int pid = findBestGamePid(true, false);
        if (pid < 10 && ctx != null && (pid = readPidFromFile(ctx)) >= 10 && findLibBase(pid, LIB_TERSAFE) == 0) {
            pid = -1;
        }
        if (pid < 10) {
            return -1;
        }
        long base = findLibBase(pid, LIB_TERSAFE);
        AppLog.d(TAG, "pid=" + pid + " libtersafe base=0x" + Long.toHexString(base));
        if (base != 0) {
            return pid;
        }
        return -1;
    }

    private static int readPidFromFile(Context ctx) {
        try {
            File f = new File(ctx.getFilesDir(), "game.pid");
            if (!f.exists()) {
                return -1;
            }
            byte[] buf = Files.readAllBytes(f.toPath());
            String s = new String(buf, StandardCharsets.UTF_8).trim();
            int pid = Integer.parseInt(s);
            if (pid >= 10 && isProcessPresent(pid)) {
                AppLog.i(TAG, "using game.pid file pid=" + pid);
                return pid;
            }
        } catch (Exception e) {
            AppLog.d(TAG, "readPidFromFile: " + e.getMessage());
        }
        return -1;
    }

    private static int findBestGamePid(boolean requireTersafe, boolean requireUe4) {
        int best = findBestGamePidScan(requireTersafe, requireUe4);
        if (best >= 10) {
            return best;
        }
        return findBestGamePidSu(requireTersafe, requireUe4);
    }

    private static int findBestGamePidSu(boolean requireTersafe, boolean requireUe4) {
        if (!Shell.rootAccess()) {
            return -1;
        }
        String tersafe = requireTersafe ? "grep -q 'libtersafe.so' $p/maps 2>/dev/null && " : "";
        String ue4 = requireUe4 ? "grep -q 'libUE4.so' $p/maps 2>/dev/null && " : "";
        String script = "best=0; bestScore=0; for p in /proc/[0-9]*; do pid=${p##*/}; " + tersafe + ue4 + "cmd=$(tr '\\0' ' ' < $p/cmdline 2>/dev/null); score=0; echo \"$cmd\" | grep -q ':' && score=$((score-100)); echo \"$cmd\" | grep -q 'com.tencent.tmgp.codev' && score=$((score+120)); echo \"$cmd\" | grep -qE 'codev|tmgp' && score=$((score+40)); grep -q 'libUE4.so' $p/maps 2>/dev/null && score=$((score+200)); grep -q 'libtersafe.so' $p/maps 2>/dev/null && score=$((score+20)); [ $score -gt $bestScore ] && bestScore=$score && best=$pid; done; echo $best";
        Shell.Result r = Shell.su(script).exec();
        if (!r.isSuccess() || r.getOut().isEmpty()) {
            return -1;
        }
        try {
            int pid = Integer.parseInt(r.getOut().get(r.getOut().size() - 1).trim());
            if (pid >= 10) {
                AppLog.i(TAG, "findBestGamePidSu pid=" + pid);
                return pid;
            }
        } catch (NumberFormatException e) {
        }
        return -1;
    }

    private static int findBestGamePidScan(boolean requireTersafe, boolean requireUe4) {
        int score;
        File proc = new File("/proc");
        File[] dirs = proc.listFiles();
        if (dirs == null) {
            return -1;
        }
        int bestScore = 0;
        int bestPid = -1;
        for (File dir : dirs) {
            if (dir.isDirectory()) {
                String name = dir.getName();
                if (name.chars().allMatch(new IntPredicate() { // from class: top.niunaijun.blackboxa.patch.GamePidHelper$$ExternalSyntheticLambda1
                    @Override // java.util.function.IntPredicate
                    public final boolean test(int i) {
                        return Character.isDigit(i);
                    }
                })) {
                    try {
                        int pid = Integer.parseInt(name);
                        if (pid >= 10 && ((!requireTersafe || findLibBase(pid, LIB_TERSAFE) != 0) && ((!requireUe4 || findLibBase(pid, LIB_UE4) != 0) && (score = scorePid(pid)) > bestScore))) {
                            bestScore = score;
                            bestPid = pid;
                        }
                    } catch (NumberFormatException e) {
                    }
                }
            }
        }
        if (bestPid >= 10 && bestPid != sLastLoggedPid) {
            sLastLoggedPid = bestPid;
            AppLog.i(TAG, String.format("game pid=%d score=%d ue4=%s tersafe=%s cmd=%s", Integer.valueOf(bestPid), Integer.valueOf(bestScore), hasUe4Loaded(bestPid) ? "yes" : "no", findLibBase(bestPid, LIB_TERSAFE) == 0 ? "no" : "yes", truncateCmdline(readCmdline(bestPid))));
        }
        return bestPid;
    }

    static int scorePid(int pid) {
        int score = 0;
        String cmd = readCmdline(pid);
        if (cmd != null) {
            int colon = cmd.indexOf(58);
            if (colon > 0) {
                score = 0 - 100;
            }
            if (cmd.contains(GAME_PACKAGE)) {
                score += 80;
                if (colon < 0) {
                    score += 40;
                }
            } else if (cmd.contains("codev") || cmd.contains("tmgp")) {
                score += 40;
            }
        }
        if (findLibBase(pid, LIB_UE4) != 0) {
            score += ItemTouchHelper.Callback.DEFAULT_DRAG_ANIMATION_DURATION;
        }
        if (findLibBase(pid, LIB_TERSAFE) != 0) {
            return score + 20;
        }
        return score;
    }

    private static String truncateCmdline(String cmd) {
        if (cmd == null || cmd.isEmpty()) {
            return "?";
        }
        return cmd.length() > 48 ? cmd.substring(0, 48) + "…" : cmd;
    }

    public static long findLibBase(int pid, String libName) {
        if (pid < 10 || libName == null || libName.isEmpty()) {
            return 0L;
        }
        long base = parseLibBaseFromMaps(readMapsLines(pid), libName);
        if (base != 0) {
            return base;
        }
        if (Shell.rootAccess()) {
            Shell.Result r = Shell.su("grep -m1 '" + libName + "' /proc/" + pid + "/maps 2>/dev/null").exec();
            if (r.isSuccess() && !r.getOut().isEmpty()) {
                base = parseLibBaseFromLine(r.getOut().get(0), libName);
                if (base != 0) {
                    AppLog.i(TAG, "findLibBase su pid=" + pid + " " + libName + " base=0x" + Long.toHexString(base));
                }
            }
        }
        return base;
    }

    private static List<String> readMapsLines(int pid) {
        ArrayList<String> lines = new ArrayList<>();
        File maps = new File("/proc/" + pid + "/maps");
        if (!maps.canRead()) {
            return lines;
        }
        try {
            BufferedReader br = new BufferedReader(new FileReader(maps));
            while (true) {
                try {
                    String line = br.readLine();
                    if (line == null) {
                        break;
                    }
                    lines.add(line);
                } finally {
                }
            }
            br.close();
        } catch (IOException e) {
            AppLog.d(TAG, "readMapsLines pid=" + pid + ": " + e.getMessage());
        }
        return lines;
    }

    private static long parseLibBaseFromMaps(List<String> lines, String libName) {
        for (String line : lines) {
            long base = parseLibBaseFromLine(line, libName);
            if (base != 0) {
                return base;
            }
        }
        return 0L;
    }

    private static long parseLibBaseFromLine(String line, String libName) {
        if (line == null || !line.contains(libName)) {
            return 0L;
        }
        try {
            String[] parts = line.split("\\s+");
            if (parts.length == 0) {
                return 0L;
            }
            String[] range = parts[0].split("-");
            if (range.length != 2) {
                return 0L;
            }
            return Long.parseLong(range[0], 16);
        } catch (NumberFormatException e) {
            return 0L;
        }
    }

    private static String readCmdline(int pid) {
        return readFirstLine(new File("/proc/" + pid + "/cmdline"));
    }

    private static String readFirstLine(File file) {
        try {
            BufferedReader br = new BufferedReader(new FileReader(file));
            try {
                String line = br.readLine();
                if (line != null) {
                    int nul = line.indexOf(0);
                    String strSubstring = nul >= 0 ? line.substring(0, nul) : line;
                    br.close();
                    return strSubstring;
                }
                br.close();
                return null;
            } finally {
            }
        } catch (IOException e) {
            return null;
        }
        return null;
    }

    public static void refreshPidFile(Context ctx) {
        int pid;
        if (ctx == null || (pid = resolveGamePid()) < 10) {
            return;
        }
        writePidToFile(ctx, pid);
    }

    public static void writePidFileOnce(Context ctx) {
        int pid;
        if (ctx != null && (pid = resolveGamePid()) >= 10) {
            writePidToFile(ctx, pid);
        }
    }

    public static void applySockPidEnv(Map<String, String> env, Context ctx) {
        if (env == null) {
            return;
        }
        int pid = resolveGamePid();
        if (pid >= 10) {
            env.put("XT_GAME_PID", String.valueOf(pid));
        }
        if (ctx != null) {
            File pidFile = new File(ctx.getFilesDir(), "game.pid");
            if (pidFile.exists()) {
                env.put("XT_GAME_PID_FILE", pidFile.getAbsolutePath());
            }
        }
    }

    private static void writePidToFile(Context ctx, int pid) {
        try {
            File f = new File(ctx.getFilesDir(), "game.pid");
            FileOutputStream fos = new FileOutputStream(f, false);
            try {
                fos.write(String.valueOf(pid).getBytes(StandardCharsets.UTF_8));
                fos.close();
            } finally {
            }
        } catch (IOException e) {
            AppLog.w(TAG, "writePidToFile failed", e);
        }
    }

    public static void startRefreshLoop(Context ctx) {
        if (ctx == null || sRefreshRunning) {
            return;
        }
        sRefreshRunning = true;
        final Context app = ctx.getApplicationContext();
        sRefreshThread = new Thread(new Runnable() { // from class: top.niunaijun.blackboxa.patch.GamePidHelper$$ExternalSyntheticLambda0
            @Override // java.lang.Runnable
            public final void run() {
                GamePidHelper.lambda$startRefreshLoop$0(app);
            }
        }, "game-pid-refresh");
        sRefreshThread.start();
    }

    static /* synthetic */ void lambda$startRefreshLoop$0(Context app) {
        while (sRefreshRunning) {
            refreshPidFile(app);
            try {
                Thread.sleep(2000L);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return;
            }
        }
    }

    public static void stopRefreshLoop() {
        sRefreshRunning = false;
        if (sRefreshThread != null) {
            sRefreshThread.interrupt();
            sRefreshThread = null;
        }
    }
}
