package top.niunaijun.blackboxa.patch;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.Toast;
import androidx.recyclerview.widget.ItemTouchHelper;
import java.io.File;
import java.io.RandomAccessFile;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import top.niunaijun.blackbox.core.env.BEnvironment;

/* JADX INFO: loaded from: classes11.dex */
public final class UeSdkDumper {
    private static final String DUMP_ROOT = "UEDump3r";
    public static final boolean ENABLED = false;
    private static final int EXPECT_DUMP_MS = 180000;
    private static final int MAX_WAIT_MS = 480000;
    private static final int POLL_MS = 2000;
    private static final String PUBG_PACKAGE = "com.pubg.imobile";
    private static final String TAG = "UEDUMP_HOST";
    private static final int UI_POLL_MS = 2000;
    private static volatile StatusListener statusListener;
    private static volatile boolean watchRunning;
    private static final String[] MARKER_FILES = {"Offsets.hpp", "AIOHeader.hpp", "SDK.hpp", "Logs.txt", "Objects.txt", "script.json"};
    private static final String CODEV_PACKAGE = "com.tencent.tmgp.codev";
    private static volatile String watchPackage = CODEV_PACKAGE;

    public interface StatusListener {
        void onStatus(String str);
    }

    private UeSdkDumper() {
    }

    public static void setStatusListener(StatusListener listener) {
        statusListener = listener;
    }

    public static boolean isCodev(String packageName) {
        return CODEV_PACKAGE.equals(packageName) || (packageName != null && packageName.contains("codev"));
    }

    public static boolean isPubg(String packageName) {
        return PUBG_PACKAGE.equals(packageName) || "com.tencent.ig".equals(packageName) || "com.rekoo.pubgm".equals(packageName) || "com.pubg.krmobile".equals(packageName) || "com.vng.pubgmobile".equals(packageName);
    }

    public static boolean isSupportedPackage(String packageName) {
        return isCodev(packageName) || isPubg(packageName);
    }

    public static boolean isUeDumpTarget(String packageName) {
        return false;
    }

    public static void requestDump(Context context, int userId, String packageName) {
    }

    public static void notifyOnLaunch(Context context, int userId) {
        notifyOnLaunch(context, userId, CODEV_PACKAGE);
    }

    public static void notifyOnLaunch(Context context, int userId, String packageName) {
    }

    private static boolean hasDumperAsset(Context app) {
        try {
            String[] assets = app.getAssets().list("");
            if (assets == null) {
                return false;
            }
            for (String name : assets) {
                if ("libUEDump3r.so".equals(name)) {
                    return true;
                }
            }
        } catch (Exception e) {
        }
        return false;
    }

    private static boolean invokeHostRequestDump(String packageName, int userId) {
        try {
            Class<?> entry = Class.forName("top.niunaijun.blackbox.closecode.Entry");
            Method m = entry.getDeclaredMethod("hostRequestDump", String.class, Integer.TYPE);
            m.invoke(null, packageName, Integer.valueOf(userId));
            emit("libUEDump3r deployed + trigger sent");
            return true;
        } catch (Exception e) {
            Log.e(TAG, "hostRequestDump reflection failed", e);
            emit("Deploy error: " + e.getMessage());
            return false;
        }
    }

    private static void startWatch(final Context app, final int userId, final String packageName) {
        synchronized (UeSdkDumper.class) {
            if (watchRunning) {
                Log.i(TAG, "dump watch already running");
                emit("Watch already running...");
            } else {
                watchRunning = true;
                new Thread(new Runnable() { // from class: top.niunaijun.blackboxa.patch.UeSdkDumper$$ExternalSyntheticLambda1
                    @Override // java.lang.Runnable
                    public final void run() throws InterruptedException {
                        UeSdkDumper.watchDump(app, userId, packageName);
                    }
                }, "ue-dump-watch").start();
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Removed duplicated region for block: B:24:0x008a A[Catch: all -> 0x02a7, TRY_ENTER, TRY_LEAVE, TryCatch #2 {all -> 0x02a7, blocks: (B:13:0x0046, B:17:0x006a, B:42:0x0134, B:44:0x0138, B:49:0x01c7, B:53:0x01ce, B:66:0x0213, B:69:0x021f, B:55:0x01d2, B:58:0x01f5, B:60:0x01f9, B:63:0x020a, B:65:0x020e, B:36:0x00ad, B:41:0x0131, B:24:0x008a, B:16:0x0055, B:75:0x023f, B:77:0x024b), top: B:94:0x0046, inners: #3 }] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static void watchDump(android.content.Context r39, int r40, java.lang.String r41) throws java.lang.InterruptedException {
        /*
            Method dump skipped, instruction units count: 689
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: top.niunaijun.blackboxa.patch.UeSdkDumper.watchDump(android.content.Context, int, java.lang.String):void");
    }

    private static void emit(final String line) {
        Log.i(TAG, "[UI] " + line);
        final StatusListener listener = statusListener;
        if (listener == null) {
            return;
        }
        if (Looper.myLooper() == Looper.getMainLooper()) {
            listener.onStatus(line);
        } else {
            new Handler(Looper.getMainLooper()).post(new Runnable() { // from class: top.niunaijun.blackboxa.patch.UeSdkDumper$$ExternalSyntheticLambda2
                @Override // java.lang.Runnable
                public final void run() {
                    listener.onStatus(line);
                }
            });
        }
    }

    private static void emitProgress(int pct, int sdkFiles, int targetSdk, String sizeLabel) {
        emit(String.format(Locale.US, "PROGRESS|%d|%d|%d|%s", Integer.valueOf(pct), Integer.valueOf(sdkFiles), Integer.valueOf(targetSdk), sizeLabel));
    }

    private static String formatBytes(long bytes) {
        if (bytes < 1024) {
            return bytes + " B";
        }
        return bytes < 1048576 ? String.format(Locale.US, "%.1f KB", Double.valueOf(bytes / 1024.0d)) : String.format(Locale.US, "%.1f MB", Double.valueOf(bytes / 1048576.0d));
    }

    private static String readDumpLogTail(File dumpDir) {
        if (dumpDir == null) {
            return null;
        }
        File log = new File(dumpDir, "Logs.txt");
        if (!log.isFile() || log.length() == 0) {
            return null;
        }
        try {
            RandomAccessFile raf = new RandomAccessFile(log, "r");
            try {
                long len = raf.length();
                int read = (int) Math.min(768L, len);
                raf.seek(len - ((long) read));
                byte[] buf = new byte[read];
                raf.readFully(buf);
                String chunk = new String(buf, StandardCharsets.UTF_8);
                int start = chunk.lastIndexOf(10, chunk.length() - 2);
                String line = (start >= 0 ? chunk.substring(start + 1) : chunk).trim();
                if (line.length() > 120) {
                    line = line.substring(line.length() - 120);
                }
                String str = line.isEmpty() ? null : line;
                raf.close();
                return str;
            } finally {
            }
        } catch (Exception e) {
            return null;
        }
    }

    private static File resolveDumpDir(int userId, String packageName) {
        File extFiles = BEnvironment.getExternalDataFilesDir(packageName, userId);
        return new File(new File(extFiles, DUMP_ROOT), packageName);
    }

    public static String guestPullHint(int userId, String packageName) {
        File root = BEnvironment.getExternalVirtualRoot();
        if (root == null) {
            return resolveDumpDir(userId, packageName).getAbsolutePath();
        }
        return root.getAbsolutePath() + "/storage/emulated/" + userId + "/Android/data/" + packageName + "/files/" + DUMP_ROOT + "/" + packageName;
    }

    private static final class DumpStatus {
        int fileCount;
        String markers;
        boolean ready;
        int sdkFileCount;
        long totalBytes;

        private DumpStatus() {
            this.markers = "";
        }
    }

    private static int countHppFiles(File dir) {
        if (dir == null || !dir.isDirectory()) {
            return 0;
        }
        int count = 0;
        File[] children = dir.listFiles();
        if (children == null) {
            return 0;
        }
        for (File child : children) {
            if (child.isDirectory()) {
                count += countHppFiles(child);
            } else if (child.isFile() && child.getName().endsWith(".hpp")) {
                count++;
            }
        }
        return count;
    }

    private static DumpStatus inspectDumpDir(File dumpDir) {
        File[] files;
        DumpStatus s = new DumpStatus();
        if (!dumpDir.isDirectory() || (files = dumpDir.listFiles()) == null) {
            return s;
        }
        int markersFound = 0;
        StringBuilder markerList = new StringBuilder();
        boolean z = false;
        for (File f : files) {
            if (f.isFile()) {
                s.fileCount++;
                s.totalBytes += f.length();
            }
        }
        File sdkDir = new File(dumpDir, "SDK");
        s.sdkFileCount = countHppFiles(sdkDir);
        s.fileCount += s.sdkFileCount;
        for (String marker : MARKER_FILES) {
            File f2 = new File(dumpDir, marker);
            if (f2.isFile() && f2.length() > 0) {
                markersFound++;
                if (markerList.length() > 0) {
                    markerList.append(", ");
                }
                markerList.append(marker).append("(").append(f2.length()).append("b)");
            }
        }
        s.markers = markerList.toString();
        File aio = new File(dumpDir, "AIOHeader.hpp");
        int minSdk = (watchPackage == null || !isPubg(watchPackage)) ? ItemTouchHelper.Callback.DEFAULT_DRAG_ANIMATION_DURATION : 150;
        if (aio.isFile() && aio.length() > 1024 && s.sdkFileCount >= minSdk) {
            z = true;
        }
        s.ready = z;
        return s;
    }

    private static void logSuccess(File dumpDir, DumpStatus status, long elapsedMs, int userId, String packageName) {
        Log.i(TAG, "========== UE SDK DUMP SUCCESS ==========");
        Log.i(TAG, "package=" + packageName + " elapsedMs=" + elapsedMs + " dir=" + dumpDir.getAbsolutePath());
        Log.i(TAG, "files=" + status.fileCount + " sdkHpp=" + status.sdkFileCount + " totalBytes=" + status.totalBytes);
        Log.i(TAG, "markers: " + status.markers);
        File sdkDir = new File(dumpDir, "SDK");
        if (sdkDir.isDirectory()) {
            Log.i(TAG, "internal SDK: SDK/ has " + status.sdkFileCount + " .hpp files");
        } else {
            Log.w(TAG, "internal SDK: SDK/ folder missing — rebuild libUEDump3r.so and re-dump");
        }
        File[] files = dumpDir.listFiles();
        if (files != null) {
            for (File f : files) {
                if (f.isFile()) {
                    Log.i(TAG, "  " + f.getName() + "  " + f.length() + " bytes");
                }
            }
        }
        Log.i(TAG, "pull (no root): adb pull \"" + guestPullHint(userId, packageName) + "\" .");
        Log.i(TAG, "=========================================");
    }

    private static void logFailure(File dumpDir, DumpStatus status, String packageName) {
        Log.e(TAG, "========== UE SDK DUMP FAILED/TIMEOUT ==========");
        Log.e(TAG, "package=" + packageName + " dir=" + dumpDir.getAbsolutePath() + " exists=" + dumpDir.isDirectory());
        Log.e(TAG, "files=" + status.fileCount + " markers=" + status.markers);
        Log.e(TAG, "check logcat: adb logcat -s UEDUMP_HOST UEDUMP_INJECT UEDump3r");
        Log.e(TAG, "ensure game reached main menu / match before dump (~65s after start)");
        Log.e(TAG, "================================================");
    }

    private static void showToast(final Context app, final String message) {
        new Handler(Looper.getMainLooper()).post(new Runnable() { // from class: top.niunaijun.blackboxa.patch.UeSdkDumper$$ExternalSyntheticLambda0
            @Override // java.lang.Runnable
            public final void run() {
                Toast.makeText(app, message, 1).show();
            }
        });
    }
}
